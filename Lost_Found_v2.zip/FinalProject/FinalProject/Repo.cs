using System;
using System.Data;
using System.Data.OleDb;

namespace FinalProject
{
    public static class Categories
    {
        public static readonly string[] All =
        {
            "Electronics", "Bags & Wallets", "IDs & Cards", "Keys", "Clothing & Accessories",
            "Books & School Supplies", "Bottles & Containers", "Jewelry", "Other"
        };
    }

    public static class ItemTypes
    {
        public const string Found = "Found";
        public const string Lost = "Lost";
        public static readonly string[] All = { Found, Lost };
    }

    public class ItemData
    {
        public string Name = "";
        public string ItemType = ItemTypes.Found;
        public string Category = "Other";
        public string Description = "";
        public string Location = "";
        public DateTime DateFound = DateTime.Today;
        public string FoundBy = "";
        public string ContactInfo = "";
        public string? PhotoPath;
    }

    public class UserProfile
    {
        public int UserID;
        public string Username = "";
        public string FullName = "";
        public string Role = "User";
        public string Email = "";
        public string ContactNumber = "";
        public string? PhotoPath;
    }

    public record LoginRecord(int UserID, string Hash, string FullName, string Role, bool Inactive);

    /// <summary>All database access lives here. Every query is parameterized.</summary>
    public static class Repo
    {
        // ---------- helpers ----------

        private static OleDbCommand Cmd(OleDbConnection con, OleDbTransaction? tx, string sql)
        {
            var cmd = new OleDbCommand(sql, con);
            if (tx != null) cmd.Transaction = tx;
            return cmd;
        }

        private static void P(OleDbCommand cmd, OleDbType type, object? value)
        {
            // OleDb parameters are positional: add them in the same order as the '?' markers.
            var p = cmd.Parameters.Add("@p" + cmd.Parameters.Count, type);
            p.Value = value ?? DBNull.Value;
        }

        private static object? NullIfEmpty(string? s)
        {
            return string.IsNullOrWhiteSpace(s) ? null : s.Trim();
        }

        private static DataTable Fill(string sql, params (OleDbType type, object? value)[] args)
        {
            using (OleDbConnection con = Database.GetConnection())
            {
                con.Open();
                using (OleDbCommand cmd = Cmd(con, null, sql))
                {
                    foreach (var a in args) P(cmd, a.type, a.value);
                    using (var adapter = new OleDbDataAdapter(cmd))
                    {
                        var table = new DataTable();
                        adapter.Fill(table);
                        return table;
                    }
                }
            }
        }

        private static bool IsActiveAdmin(OleDbConnection con, OleDbTransaction? tx, int userId)
        {
            using (OleDbCommand cmd = Cmd(con, tx,
                "SELECT COUNT(*) FROM Users WHERE UserID = ? AND UserRole = 'Admin' " +
                "AND (InActive = False OR InActive IS NULL)"))
            {
                P(cmd, OleDbType.Integer, userId);
                return Convert.ToInt32(cmd.ExecuteScalar()) > 0;
            }
        }

        private const string NoAdminRights = "You no longer have administrator rights.";

        // ---------- authentication / accounts ----------

        public static LoginRecord? FindLogin(string username)
        {
            using (OleDbConnection con = Database.GetConnection())
            {
                con.Open();
                using (OleDbCommand cmd = Cmd(con, null,
                    "SELECT UserID, PasswordHash, FullName, UserRole, InActive FROM Users WHERE Username = ?"))
                {
                    P(cmd, OleDbType.VarWChar, username);
                    using (OleDbDataReader r = cmd.ExecuteReader())
                    {
                        if (!r.Read()) return null;
                        return new LoginRecord(
                            Convert.ToInt32(r["UserID"]),
                            Convert.ToString(r["PasswordHash"]) ?? "",
                            Convert.ToString(r["FullName"]) ?? "",
                            Convert.ToString(r["UserRole"]) ?? "User",
                            r["InActive"] != DBNull.Value && Convert.ToBoolean(r["InActive"]));
                    }
                }
            }
        }

        public static void UpgradePasswordHash(int userId, string password)
        {
            using (OleDbConnection con = Database.GetConnection())
            {
                con.Open();
                using (OleDbCommand cmd = Cmd(con, null, "UPDATE Users SET PasswordHash = ? WHERE UserID = ?"))
                {
                    P(cmd, OleDbType.LongVarWChar, PasswordHelper.HashPassword(password));
                    P(cmd, OleDbType.Integer, userId);
                    cmd.ExecuteNonQuery();
                }
            }
        }

        /// <summary>Returns an error message, or null when the account was created.</summary>
        public static string? Register(string fullName, string username, string password)
        {
            using (OleDbConnection con = Database.GetConnection())
            {
                con.Open();

                using (OleDbCommand check = Cmd(con, null, "SELECT COUNT(*) FROM Users WHERE Username = ?"))
                {
                    P(check, OleDbType.VarWChar, username);
                    if (Convert.ToInt32(check.ExecuteScalar()) > 0)
                        return "That username is already taken.";
                }

                using (OleDbCommand cmd = Cmd(con, null,
                    "INSERT INTO Users (Username, PasswordHash, FullName, UserRole, InActive) VALUES (?, ?, ?, ?, ?)"))
                {
                    P(cmd, OleDbType.VarWChar, username);
                    P(cmd, OleDbType.LongVarWChar, PasswordHelper.HashPassword(password));
                    P(cmd, OleDbType.VarWChar, fullName);
                    P(cmd, OleDbType.VarWChar, "User");
                    P(cmd, OleDbType.Boolean, false);
                    return cmd.ExecuteNonQuery() > 0 ? null : "Registration failed. Please try again.";
                }
            }
        }

        public static UserProfile? GetProfile(int userId)
        {
            DataTable t = Fill(
                "SELECT UserID, Username, FullName, UserRole, Email, ContactNumber, PhotoPath FROM Users WHERE UserID = ?",
                (OleDbType.Integer, userId));
            if (t.Rows.Count == 0) return null;

            DataRow r = t.Rows[0];
            return new UserProfile
            {
                UserID = userId,
                Username = Convert.ToString(r["Username"]) ?? "",
                FullName = Convert.ToString(r["FullName"]) ?? "",
                Role = Convert.ToString(r["UserRole"]) ?? "User",
                Email = Convert.ToString(r["Email"]) ?? "",
                ContactNumber = Convert.ToString(r["ContactNumber"]) ?? "",
                PhotoPath = r["PhotoPath"] == DBNull.Value ? null : Convert.ToString(r["PhotoPath"])
            };
        }

        public static void UpdateProfile(int userId, string fullName, string email, string contact, string? photo)
        {
            using (OleDbConnection con = Database.GetConnection())
            {
                con.Open();
                using (OleDbCommand cmd = Cmd(con, null,
                    "UPDATE Users SET FullName = ?, Email = ?, ContactNumber = ?, PhotoPath = ? WHERE UserID = ?"))
                {
                    P(cmd, OleDbType.VarWChar, fullName.Trim());
                    P(cmd, OleDbType.VarWChar, NullIfEmpty(email));
                    P(cmd, OleDbType.VarWChar, NullIfEmpty(contact));
                    P(cmd, OleDbType.VarWChar, NullIfEmpty(photo));
                    P(cmd, OleDbType.Integer, userId);
                    cmd.ExecuteNonQuery();
                }
            }
        }

        /// <summary>Returns an error message, or null on success.</summary>
        public static string? ChangePassword(int userId, string currentPassword, string newPassword)
        {
            using (OleDbConnection con = Database.GetConnection())
            {
                con.Open();

                string stored;
                using (OleDbCommand cmd = Cmd(con, null, "SELECT PasswordHash FROM Users WHERE UserID = ?"))
                {
                    P(cmd, OleDbType.Integer, userId);
                    stored = Convert.ToString(cmd.ExecuteScalar()) ?? "";
                }

                if (!PasswordHelper.VerifyPassword(currentPassword, stored))
                    return "Your current password is incorrect.";

                using (OleDbCommand cmd = Cmd(con, null, "UPDATE Users SET PasswordHash = ? WHERE UserID = ?"))
                {
                    P(cmd, OleDbType.LongVarWChar, PasswordHelper.HashPassword(newPassword));
                    P(cmd, OleDbType.Integer, userId);
                    cmd.ExecuteNonQuery();
                }
                return null;
            }
        }

        // ---------- user management (admin) ----------

        public static DataTable GetUsers()
        {
            return Fill(
                "SELECT UserID, Username, FullName, UserRole, " +
                "IIf(InActive = True, 'Deactivated', 'Active') AS AccountStatus, " +
                "IIf(InActive = True, 1, 0) AS InactiveFlag, ContactNumber, Email " +
                "FROM Users ORDER BY FullName");
        }

        public static string? SetUserRole(int actingUserId, int targetUserId, string newRole)
        {
            if (actingUserId == targetUserId) return "You can't change your own role.";

            using (OleDbConnection con = Database.GetConnection())
            {
                con.Open();
                if (!IsActiveAdmin(con, null, actingUserId)) return NoAdminRights;

                using (OleDbCommand cmd = Cmd(con, null, "UPDATE Users SET UserRole = ? WHERE UserID = ?"))
                {
                    P(cmd, OleDbType.VarWChar, newRole);
                    P(cmd, OleDbType.Integer, targetUserId);
                    cmd.ExecuteNonQuery();
                }
                return null;
            }
        }

        public static string? SetUserInactive(int actingUserId, int targetUserId, bool inactive)
        {
            if (actingUserId == targetUserId) return "You can't deactivate your own account.";

            using (OleDbConnection con = Database.GetConnection())
            {
                con.Open();
                if (!IsActiveAdmin(con, null, actingUserId)) return NoAdminRights;

                using (OleDbCommand cmd = Cmd(con, null, "UPDATE Users SET InActive = ? WHERE UserID = ?"))
                {
                    P(cmd, OleDbType.Boolean, inactive);
                    P(cmd, OleDbType.Integer, targetUserId);
                    cmd.ExecuteNonQuery();
                }
                return null;
            }
        }

        // ---------- items ----------

        private const string ItemSelect =
            "SELECT ItemID, ItemName, IIf(ItemType Is Null, 'Found', ItemType) AS TypeName, " +
            "IIf(Category Is Null, 'Other', Category) AS CategoryName, " +
            "[Description], LocationFound, DateFound, Status, FoundBy, ContactInfo, PhotoPath, " +
            "IIf(IsArchived = True, 1, 0) AS ArchivedFlag, " +
            "IIf(IsArchived = True, 'Archived', Status) AS StatusDisplay FROM LostItems ";

        /// <summary>Admins get everything (archived included, filtered in the UI). Others only see open items.</summary>
        public static DataTable GetItems(bool isAdmin)
        {
            string where = isAdmin
                ? ""
                : "WHERE Status = 'Available' AND (IsArchived = False OR IsArchived Is Null) ";
            return Fill(ItemSelect + where + "ORDER BY DateFound DESC, ItemID DESC");
        }

        public static string? AddItem(int actingUserId, ItemData d)
        {
            using (OleDbConnection con = Database.GetConnection())
            {
                con.Open();
                if (!IsActiveAdmin(con, null, actingUserId)) return NoAdminRights;

                using (OleDbCommand cmd = Cmd(con, null,
                    "INSERT INTO LostItems (ItemName, ItemType, Category, [Description], LocationFound, DateFound, " +
                    "Status, FoundBy, ContactInfo, PhotoPath, IsArchived) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"))
                {
                    P(cmd, OleDbType.VarWChar, d.Name.Trim());
                    P(cmd, OleDbType.VarWChar, d.ItemType == ItemTypes.Lost ? ItemTypes.Lost : ItemTypes.Found);
                    P(cmd, OleDbType.VarWChar, d.Category);
                    P(cmd, OleDbType.LongVarWChar, d.Description.Trim());
                    P(cmd, OleDbType.VarWChar, d.Location.Trim());
                    P(cmd, OleDbType.Date, d.DateFound.Date);
                    P(cmd, OleDbType.VarWChar, "Available");
                    P(cmd, OleDbType.VarWChar, NullIfEmpty(d.FoundBy));
                    P(cmd, OleDbType.VarWChar, NullIfEmpty(d.ContactInfo));
                    P(cmd, OleDbType.VarWChar, NullIfEmpty(d.PhotoPath));
                    P(cmd, OleDbType.Boolean, false);
                    cmd.ExecuteNonQuery();
                }
                return null;
            }
        }

        public static string? UpdateItem(int actingUserId, int itemId, ItemData d)
        {
            using (OleDbConnection con = Database.GetConnection())
            {
                con.Open();
                if (!IsActiveAdmin(con, null, actingUserId)) return NoAdminRights;

                using (OleDbCommand cmd = Cmd(con, null,
                    "UPDATE LostItems SET ItemName = ?, ItemType = ?, Category = ?, [Description] = ?, LocationFound = ?, " +
                    "DateFound = ?, FoundBy = ?, ContactInfo = ?, PhotoPath = ? WHERE ItemID = ?"))
                {
                    P(cmd, OleDbType.VarWChar, d.Name.Trim());
                    P(cmd, OleDbType.VarWChar, d.ItemType == ItemTypes.Lost ? ItemTypes.Lost : ItemTypes.Found);
                    P(cmd, OleDbType.VarWChar, d.Category);
                    P(cmd, OleDbType.LongVarWChar, d.Description.Trim());
                    P(cmd, OleDbType.VarWChar, d.Location.Trim());
                    P(cmd, OleDbType.Date, d.DateFound.Date);
                    P(cmd, OleDbType.VarWChar, NullIfEmpty(d.FoundBy));
                    P(cmd, OleDbType.VarWChar, NullIfEmpty(d.ContactInfo));
                    P(cmd, OleDbType.VarWChar, NullIfEmpty(d.PhotoPath));
                    P(cmd, OleDbType.Integer, itemId);
                    cmd.ExecuteNonQuery();
                }
                return null;
            }
        }

        public static int CountPendingClaims(int itemId)
        {
            DataTable t = Fill(
                "SELECT COUNT(*) FROM ClaimRequests WHERE ItemID = ? AND RequestStatus = 'Pending'",
                (OleDbType.Integer, itemId));
            return Convert.ToInt32(t.Rows[0][0]);
        }

        /// <summary>Archives or restores an item. Nothing is ever deleted. Pending claims on an archived item are rejected.</summary>
        public static string? SetArchived(int actingUserId, int itemId, bool archived)
        {
            using (OleDbConnection con = Database.GetConnection())
            {
                con.Open();
                if (!IsActiveAdmin(con, null, actingUserId)) return NoAdminRights;

                using (OleDbTransaction tx = con.BeginTransaction())
                {
                    try
                    {
                        if (archived)
                        {
                            using (OleDbCommand cmd = Cmd(con, tx,
                                "UPDATE ClaimRequests SET RequestStatus = 'Rejected' " +
                                "WHERE ItemID = ? AND RequestStatus = 'Pending'"))
                            {
                                P(cmd, OleDbType.Integer, itemId);
                                cmd.ExecuteNonQuery();
                            }
                        }

                        using (OleDbCommand cmd = Cmd(con, tx,
                            "UPDATE LostItems SET IsArchived = ?, DateArchived = ? WHERE ItemID = ?"))
                        {
                            P(cmd, OleDbType.Boolean, archived);
                            P(cmd, OleDbType.Date, archived ? DateTime.Now : null);
                            P(cmd, OleDbType.Integer, itemId);
                            cmd.ExecuteNonQuery();
                        }

                        tx.Commit();
                        return null;
                    }
                    catch
                    {
                        tx.Rollback();
                        throw;
                    }
                }
            }
        }

        // ---------- item reports (user submits, admin approves) ----------

        private const int MaxPendingReports = 5;

        /// <summary>Saves a user's lost/found report as Pending. Returns an error message, or null on success.</summary>
        public static string? SubmitReport(int userId, ItemData d)
        {
            using (OleDbConnection con = Database.GetConnection())
            {
                con.Open();

                using (OleDbCommand cmd = Cmd(con, null,
                    "SELECT COUNT(*) FROM Users WHERE UserID = ? AND (InActive = False OR InActive IS NULL)"))
                {
                    P(cmd, OleDbType.Integer, userId);
                    if (Convert.ToInt32(cmd.ExecuteScalar()) == 0) return "Your account is unavailable.";
                }

                using (OleDbCommand cmd = Cmd(con, null,
                    "SELECT COUNT(*) FROM ItemReports WHERE UserID = ? AND ReportStatus = 'Pending'"))
                {
                    P(cmd, OleDbType.Integer, userId);
                    if (Convert.ToInt32(cmd.ExecuteScalar()) >= MaxPendingReports)
                        return "You already have " + MaxPendingReports +
                               " reports waiting for review. Please wait for an administrator to review them first.";
                }

                using (OleDbCommand cmd = Cmd(con, null,
                    "INSERT INTO ItemReports (UserID, ItemType, ItemName, Category, [Description], LocationName, " +
                    "EventDate, ReporterName, ContactInfo, PhotoPath, ReportStatus, SubmittedAt) " +
                    "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"))
                {
                    P(cmd, OleDbType.Integer, userId);
                    P(cmd, OleDbType.VarWChar, d.ItemType == ItemTypes.Lost ? ItemTypes.Lost : ItemTypes.Found);
                    P(cmd, OleDbType.VarWChar, d.Name.Trim());
                    P(cmd, OleDbType.VarWChar, d.Category);
                    P(cmd, OleDbType.LongVarWChar, d.Description.Trim());
                    P(cmd, OleDbType.VarWChar, d.Location.Trim());
                    P(cmd, OleDbType.Date, d.DateFound.Date);
                    P(cmd, OleDbType.VarWChar, NullIfEmpty(d.FoundBy));
                    P(cmd, OleDbType.VarWChar, NullIfEmpty(d.ContactInfo));
                    P(cmd, OleDbType.VarWChar, NullIfEmpty(d.PhotoPath));
                    P(cmd, OleDbType.VarWChar, "Pending");
                    P(cmd, OleDbType.Date, DateTime.Now);
                    cmd.ExecuteNonQuery();
                }
                return null;
            }
        }

        public static DataTable GetAllReports()
        {
            return Fill(
                "SELECT r.ReportID, r.ItemType AS TypeName, r.ItemName, r.Category AS CategoryName, " +
                "r.[Description], r.LocationName, r.EventDate, r.ReporterName, r.ContactInfo, r.PhotoPath, " +
                "r.ReportStatus, r.SubmittedAt, u.FullName AS SubmitterName, u.Username " +
                "FROM ItemReports AS r INNER JOIN Users AS u ON r.UserID = u.UserID " +
                "ORDER BY r.SubmittedAt DESC");
        }

        public static DataTable GetReportsForUser(int userId)
        {
            return Fill(
                "SELECT ReportID, ItemType AS TypeName, ItemName, EventDate, SubmittedAt, ReportStatus " +
                "FROM ItemReports WHERE UserID = ? ORDER BY SubmittedAt DESC",
                (OleDbType.Integer, userId));
        }

        /// <summary>
        /// Approves or rejects a pending report. Approving copies the submitted details into LostItems,
        /// so the item is posted automatically. Returns an error message, or null on success.
        /// </summary>
        public static string? ProcessReport(int actingUserId, int reportId, bool approve)
        {
            using (OleDbConnection con = Database.GetConnection())
            {
                con.Open();
                if (!IsActiveAdmin(con, null, actingUserId)) return NoAdminRights;

                using (OleDbTransaction tx = con.BeginTransaction())
                {
                    try
                    {
                        string type = "", name = "", category = "", desc = "", location = "", by = "",
                               contact = "", photo = "", status = "";
                        DateTime when = DateTime.Today;
                        bool found = false;

                        using (OleDbCommand cmd = Cmd(con, tx,
                            "SELECT ItemType, ItemName, Category, [Description], LocationName, EventDate, " +
                            "ReporterName, ContactInfo, PhotoPath, ReportStatus FROM ItemReports WHERE ReportID = ?"))
                        {
                            P(cmd, OleDbType.Integer, reportId);
                            using (OleDbDataReader rd = cmd.ExecuteReader())
                            {
                                if (rd.Read())
                                {
                                    found = true;
                                    type = Convert.ToString(rd["ItemType"]) ?? "";
                                    name = Convert.ToString(rd["ItemName"]) ?? "";
                                    category = Convert.ToString(rd["Category"]) ?? "";
                                    desc = Convert.ToString(rd["Description"]) ?? "";
                                    location = Convert.ToString(rd["LocationName"]) ?? "";
                                    if (rd["EventDate"] is DateTime dt) when = dt;
                                    by = Convert.ToString(rd["ReporterName"]) ?? "";
                                    contact = Convert.ToString(rd["ContactInfo"]) ?? "";
                                    photo = Convert.ToString(rd["PhotoPath"]) ?? "";
                                    status = Convert.ToString(rd["ReportStatus"]) ?? "";
                                }
                            }
                        }

                        if (!found) { tx.Rollback(); return "Report not found."; }
                        if (status != "Pending") { tx.Rollback(); return "This report has already been reviewed."; }

                        if (approve)
                        {
                            using (OleDbCommand cmd = Cmd(con, tx,
                                "INSERT INTO LostItems (ItemName, ItemType, Category, [Description], LocationFound, " +
                                "DateFound, Status, FoundBy, ContactInfo, PhotoPath, IsArchived) " +
                                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"))
                            {
                                P(cmd, OleDbType.VarWChar, name);
                                P(cmd, OleDbType.VarWChar, type == ItemTypes.Lost ? ItemTypes.Lost : ItemTypes.Found);
                                P(cmd, OleDbType.VarWChar, category.Length > 0 ? category : "Other");
                                P(cmd, OleDbType.LongVarWChar, desc);
                                P(cmd, OleDbType.VarWChar, location);
                                P(cmd, OleDbType.Date, when.Date);
                                P(cmd, OleDbType.VarWChar, "Available");
                                P(cmd, OleDbType.VarWChar, NullIfEmpty(by));
                                P(cmd, OleDbType.VarWChar, NullIfEmpty(contact));
                                P(cmd, OleDbType.VarWChar, NullIfEmpty(photo));
                                P(cmd, OleDbType.Boolean, false);
                                cmd.ExecuteNonQuery();
                            }
                        }

                        using (OleDbCommand cmd = Cmd(con, tx,
                            "UPDATE ItemReports SET ReportStatus = ?, ReviewedAt = ? " +
                            "WHERE ReportID = ? AND ReportStatus = 'Pending'"))
                        {
                            P(cmd, OleDbType.VarWChar, approve ? "Approved" : "Rejected");
                            P(cmd, OleDbType.Date, DateTime.Now);
                            P(cmd, OleDbType.Integer, reportId);
                            if (cmd.ExecuteNonQuery() == 0)
                            {
                                tx.Rollback();
                                return "This report has already been reviewed.";
                            }
                        }

                        tx.Commit();
                        return null;
                    }
                    catch
                    {
                        tx.Rollback();
                        throw;
                    }
                }
            }
        }

        // ---------- claims ----------

        /// <summary>Returns an error message, or null when the claim was submitted.</summary>
        public static string? SubmitClaim(int itemId, int userId, string details, string contact, string? proofPhoto)
        {
            using (OleDbConnection con = Database.GetConnection())
            {
                con.Open();

                using (OleDbCommand cmd = Cmd(con, null,
                    "SELECT COUNT(*) FROM LostItems WHERE ItemID = ? AND Status = 'Available' " +
                    "AND (IsArchived = False OR IsArchived IS NULL) AND (ItemType IS NULL OR ItemType <> 'Lost')"))
                {
                    P(cmd, OleDbType.Integer, itemId);
                    if (Convert.ToInt32(cmd.ExecuteScalar()) == 0)
                        return "This item is no longer available to claim.";
                }

                using (OleDbCommand cmd = Cmd(con, null,
                    "SELECT COUNT(*) FROM ClaimRequests WHERE ItemID = ? AND UserID = ? AND RequestStatus = 'Pending'"))
                {
                    P(cmd, OleDbType.Integer, itemId);
                    P(cmd, OleDbType.Integer, userId);
                    if (Convert.ToInt32(cmd.ExecuteScalar()) > 0)
                        return "You already have a pending claim for this item.";
                }

                using (OleDbCommand cmd = Cmd(con, null,
                    "INSERT INTO ClaimRequests (ItemID, UserID, ClaimDetails, RequestDate, RequestStatus, " +
                    "ProofPhotoPath, ContactInfo) VALUES (?, ?, ?, ?, ?, ?, ?)"))
                {
                    P(cmd, OleDbType.Integer, itemId);
                    P(cmd, OleDbType.Integer, userId);
                    P(cmd, OleDbType.LongVarWChar, details.Trim());
                    P(cmd, OleDbType.Date, DateTime.Now);
                    P(cmd, OleDbType.VarWChar, "Pending");
                    P(cmd, OleDbType.VarWChar, NullIfEmpty(proofPhoto));
                    P(cmd, OleDbType.VarWChar, NullIfEmpty(contact));
                    cmd.ExecuteNonQuery();
                }
                return null;
            }
        }

        public static DataTable GetAllClaims()
        {
            return Fill(
                "SELECT c.ClaimID, c.ItemID, i.ItemName, i.PhotoPath AS ItemPhoto, u.FullName, u.Username, " +
                "c.ContactInfo AS ClaimContact, u.ContactNumber, u.Email, c.ClaimDetails, c.RequestDate, " +
                "c.RequestStatus, c.ProofPhotoPath " +
                "FROM (ClaimRequests AS c INNER JOIN LostItems AS i ON c.ItemID = i.ItemID) " +
                "INNER JOIN Users AS u ON c.UserID = u.UserID " +
                "ORDER BY c.RequestDate DESC");
        }

        public static DataTable GetClaimsForUser(int userId)
        {
            return Fill(
                "SELECT c.ClaimID, i.ItemName, c.ClaimDetails, c.RequestDate, c.RequestStatus, i.ContactInfo AS HeldAt " +
                "FROM ClaimRequests AS c INNER JOIN LostItems AS i ON c.ItemID = i.ItemID " +
                "WHERE c.UserID = ? ORDER BY c.RequestDate DESC",
                (OleDbType.Integer, userId));
        }

        /// <summary>Approves or rejects a pending claim. Returns an error message, or null on success.</summary>
        public static string? ProcessClaim(int actingUserId, int claimId, string status)
        {
            using (OleDbConnection con = Database.GetConnection())
            {
                con.Open();
                if (!IsActiveAdmin(con, null, actingUserId)) return NoAdminRights;

                using (OleDbTransaction tx = con.BeginTransaction())
                {
                    try
                    {
                        int itemId;
                        using (OleDbCommand cmd = Cmd(con, tx, "SELECT ItemID FROM ClaimRequests WHERE ClaimID = ?"))
                        {
                            P(cmd, OleDbType.Integer, claimId);
                            object? o = cmd.ExecuteScalar();
                            if (o == null || o == DBNull.Value) { tx.Rollback(); return "Claim request not found."; }
                            itemId = Convert.ToInt32(o);
                        }

                        if (status == "Approved")
                        {
                            using (OleDbCommand cmd = Cmd(con, tx,
                                "SELECT COUNT(*) FROM LostItems WHERE ItemID = ? AND Status = 'Available' " +
                                "AND (IsArchived = False OR IsArchived IS NULL)"))
                            {
                                P(cmd, OleDbType.Integer, itemId);
                                if (Convert.ToInt32(cmd.ExecuteScalar()) == 0)
                                {
                                    tx.Rollback();
                                    return "This item has already been claimed or is archived.";
                                }
                            }
                        }

                        using (OleDbCommand cmd = Cmd(con, tx,
                            "UPDATE ClaimRequests SET RequestStatus = ? WHERE ClaimID = ? AND RequestStatus = 'Pending'"))
                        {
                            P(cmd, OleDbType.VarWChar, status);
                            P(cmd, OleDbType.Integer, claimId);
                            if (cmd.ExecuteNonQuery() == 0)
                            {
                                tx.Rollback();
                                return "This claim has already been processed.";
                            }
                        }

                        if (status == "Approved")
                        {
                            using (OleDbCommand cmd = Cmd(con, tx, "UPDATE LostItems SET Status = 'Claimed' WHERE ItemID = ?"))
                            {
                                P(cmd, OleDbType.Integer, itemId);
                                cmd.ExecuteNonQuery();
                            }

                            using (OleDbCommand cmd = Cmd(con, tx,
                                "UPDATE ClaimRequests SET RequestStatus = 'Rejected' " +
                                "WHERE ItemID = ? AND ClaimID <> ? AND RequestStatus = 'Pending'"))
                            {
                                P(cmd, OleDbType.Integer, itemId);
                                P(cmd, OleDbType.Integer, claimId);
                                cmd.ExecuteNonQuery();
                            }
                        }

                        tx.Commit();
                        return null;
                    }
                    catch
                    {
                        try { tx.Rollback(); } catch { }
                        throw;
                    }
                }
            }
        }
    }
}
