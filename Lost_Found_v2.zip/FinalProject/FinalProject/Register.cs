using System;
using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace FinalProject
{
    public partial class Register : Form
    {
        private static readonly Regex UsernameRule = new Regex(@"^[A-Za-z0-9_.]{3,30}$", RegexOptions.Compiled);

        private RoundedPanel card = null!;
        private BackdropPanel backdrop = null!;
        private TextBox txtFullname = null!;
        private TextBox txtUsername = null!;
        private TextBox txtPassword = null!;
        private TextBox txtConfirmPassword = null!;
        private CheckBox chkShow = null!;
        private Button btnRegister = null!;
        private LinkLabel linkSignUp = null!;

        public Register()
        {
            BuildUi();
        }

        private void BuildUi()
        {
            AutoScaleMode = AutoScaleMode.Dpi;
            AutoScaleDimensions = new SizeF(96F, 96F);
            Text = "Lost & Found - Create account";
            ClientSize = new Size(1000, 700);
            MinimumSize = new Size(820, 700);
            StartPosition = FormStartPosition.CenterParent;
            ShowInTaskbar = false;

            backdrop = new BackdropPanel { Dock = DockStyle.Fill };
            Controls.Add(backdrop);

            card = new RoundedPanel { Size = new Size(400, 600), Radius = 16 };
            backdrop.Controls.Add(card);

            var logo = new PictureBox
            {
                Image = Properties.Resources.e010249b12c608141e27e869b389025d,
                SizeMode = PictureBoxSizeMode.Zoom,
                Size = new Size(56, 56),
                Location = new Point((card.Width - 56) / 2, 20),
                BackColor = Color.Transparent
            };
            card.Controls.Add(logo);

            card.Controls.Add(new Label
            {
                Text = "CREATE ACCOUNT",
                Font = Theme.Body(18f, FontStyle.Bold),
                ForeColor = Theme.Primary,
                AutoSize = false,
                UseMnemonic = false,
                TextAlign = ContentAlignment.MiddleCenter,
                Size = new Size(card.Width, 34),
                Location = new Point(0, 82)
            });
            card.Controls.Add(new Label
            {
                Text = "Lost & Found  |  Bulacan Polytechnic College",
                Font = Theme.Body(9.5f),
                ForeColor = Theme.TextMuted,
                AutoSize = false,
                UseMnemonic = false,
                TextAlign = ContentAlignment.MiddleCenter,
                Size = new Size(card.Width, 20),
                Location = new Point(0, 116)
            });

            int x = 40, w = card.Width - 80, y = 152;

            txtFullname = AddField("Full name", ref y, x, w, false);
            txtUsername = AddField("Username (letters, numbers, . or _)", ref y, x, w, false);
            txtPassword = AddField("Password (8+ chars, letters and numbers)", ref y, x, w, true);
            txtConfirmPassword = AddField("Confirm password", ref y, x, w, true);
            txtFullname.MaxLength = 80;
            txtUsername.MaxLength = 30;

            chkShow = new CheckBox
            {
                Text = "Show passwords",
                AutoSize = true,
                Font = Theme.Body(9f),
                ForeColor = Theme.TextMuted,
                Location = new Point(x, y - 4)
            };
            chkShow.CheckedChanged += (s, e) =>
            {
                txtPassword.UseSystemPasswordChar = !chkShow.Checked;
                txtConfirmPassword.UseSystemPasswordChar = !chkShow.Checked;
            };
            card.Controls.Add(chkShow);

            btnRegister = Theme.MakeButton("REGISTER", Theme.Primary, Color.White, w, 44);
            btnRegister.Location = new Point(x, y + 28);
            btnRegister.Click += btnRegister_Click;
            card.Controls.Add(btnRegister);

            linkSignUp = new LinkLabel
            {
                Text = "Already have an account? Sign in",
                AutoSize = false,
                UseMnemonic = false,
                TextAlign = ContentAlignment.MiddleCenter,
                Size = new Size(card.Width, 24),
                Location = new Point(0, y + 88),
                Font = Theme.Body(9.5f),
                LinkColor = Theme.Primary,
                ActiveLinkColor = Theme.PrimaryDark,
                BackColor = Color.Transparent
            };
            linkSignUp.LinkClicked += (s, e) => Close();
            card.Controls.Add(linkSignUp);

            AcceptButton = btnRegister;
            backdrop.Resize += (s, e) => CenterCard();
            Shown += (s, e) => { CenterCard(); txtFullname.Focus(); };
        }

        private TextBox AddField(string caption, ref int y, int x, int w, bool password)
        {
            var lbl = Theme.MakeLabel(caption, 9.5f, FontStyle.Bold, Theme.TextDark);
            lbl.Location = new Point(x, y);
            card.Controls.Add(lbl);

            var tb = Theme.MakeTextBox(w);
            tb.Location = new Point(x, y + 22);
            tb.UseSystemPasswordChar = password;
            card.Controls.Add(tb);

            y += 66;
            return tb;
        }

        private void CenterCard()
        {
            card.Location = new Point(
                Math.Max(0, (backdrop.ClientSize.Width - card.Width) / 2),
                Math.Max(0, (backdrop.ClientSize.Height - card.Height) / 2));
        }

        private void btnRegister_Click(object? sender, EventArgs e)
        {
            string fullName = txtFullname.Text.Trim();
            string username = txtUsername.Text.Trim();
            string password = txtPassword.Text;
            string confirm = txtConfirmPassword.Text;

            if (fullName.Length == 0 || username.Length == 0 || password.Length == 0 || confirm.Length == 0)
            {
                Theme.Warn(this, "Please fill in all fields.");
                return;
            }

            if (!UsernameRule.IsMatch(username))
            {
                Theme.Warn(this, "Username must be 3-30 characters: letters, numbers, dots or underscores only.");
                return;
            }

            if (password != confirm)
            {
                Theme.Warn(this, "Passwords do not match.");
                return;
            }

            string? weak = PasswordHelper.Validate(password);
            if (weak != null)
            {
                Theme.Warn(this, weak);
                return;
            }

            try
            {
                string? error = Repo.Register(fullName, username, password);
                if (error != null)
                {
                    Theme.Warn(this, error);
                    return;
                }

                Theme.Info(this, "Account created. You can now sign in.");
                Close();
            }
            catch (Exception)
            {
                Theme.Error(this, "Registration is unavailable right now. Please try again later.");
            }
        }
    }
}
