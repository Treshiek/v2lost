using System;
using System.Windows.Forms;

namespace FinalProject
{
    public partial class Dashboard
    {
        // shell
        private readonly Panel header = new Panel();
        private readonly PictureBox picAvatar = new PictureBox();
        private readonly Label lblUserName = new Label();
        private readonly Label lblUserRole = new Label();
        private Button btnLogout = null!;
        private readonly Panel content = new Panel();
        private readonly Label lblToast = new Label();
        private readonly System.Windows.Forms.Timer toastTimer = new System.Windows.Forms.Timer { Interval = 4500 };

        // navigation
        private readonly Dictionary<Button, Panel> navMap = new Dictionary<Button, Panel>();
        private Button navItems = null!, navClaims = null!, navUsers = null!, navProfile = null!;
        private readonly Panel viewItems = new Panel();
        private readonly Panel viewClaims = new Panel();
        private readonly Panel viewMyClaims = new Panel();
        private readonly Panel viewUsers = new Panel();
        private readonly Panel viewProfile = new Panel();

        // items
        private readonly TextBox txtSearch = Theme.MakeTextBox(300);
        private readonly ComboBox cboCategory = Theme.MakeCombo(180);
        private readonly ComboBox cboStatus = Theme.MakeCombo(190, "Active items", "Available only", "Claimed only", "Archived", "Everything");
        private readonly Label lblCount = Theme.MakeLabel("", 9.5f, FontStyle.Regular, Theme.TextMuted);
        private readonly DataGridView dgvItems = new DataGridView();
        private readonly PictureBox picItem = new PictureBox();
        private readonly FlowLayoutPanel pnlItemFields = new FlowLayoutPanel();
        private readonly Label lblNoSelection = new Label();
        private readonly Panel pnlItemButtons = new Panel();
        private readonly Label lblDName = Theme.MakeLabel("", 13f, FontStyle.Bold, Theme.TextDark);
        private readonly Label lblDStatus = Theme.MakeLabel("", 8.5f, FontStyle.Bold, Color.White);
        private Label lblDCategory = null!, lblDLocation = null!, lblDDate = null!,
                      lblDFoundBy = null!, lblDContact = null!, lblDDescription = null!;
        private Button btnArchive = null!, btnClaim = null!;

        // claims (admin)
        private readonly TextBox txtClaimSearch = Theme.MakeTextBox(300);
        private readonly ComboBox cboClaimStatus = Theme.MakeCombo(160, "Pending", "Approved", "Rejected", "All");
        private readonly DataGridView dgvClaims = new DataGridView();
        private readonly PictureBox picClaimItem = new PictureBox();
        private readonly PictureBox picClaimProof = new PictureBox();
        private readonly FlowLayoutPanel pnlClaimFields = new FlowLayoutPanel();
        private readonly Label lblNoClaim = new Label();
        private readonly Panel pnlClaimButtons = new Panel();
        private readonly Label lblCItem = Theme.MakeLabel("", 13f, FontStyle.Bold, Theme.TextDark);
        private readonly Label lblCStatus = Theme.MakeLabel("", 8.5f, FontStyle.Bold, Color.White);
        private Label lblCClaimant = null!, lblCContact = null!, lblCDate = null!, lblCDetails = null!;
        private Button btnApprove = null!, btnReject = null!;

        // my claims (user)
        private readonly DataGridView dgvMyClaims = new DataGridView();
        private readonly Label lblMyClaimsEmpty = new Label();

        // users (admin)
        private readonly TextBox txtUserSearch = Theme.MakeTextBox(300);
        private readonly DataGridView dgvUsers = new DataGridView();
        private Button btnRole = null!, btnActive = null!;

        // profile
        private readonly PictureBox picProfile = new PictureBox();
        private readonly TextBox txtPFullName = Theme.MakeTextBox(412);
        private readonly TextBox txtPUsername = Theme.MakeTextBox(412);
        private readonly TextBox txtPRole = Theme.MakeTextBox(412);
        private readonly TextBox txtPEmail = Theme.MakeTextBox(412);
        private readonly TextBox txtPContact = Theme.MakeTextBox(412);
        private readonly TextBox txtCurPass = Theme.MakeTextBox(352);
        private readonly TextBox txtNewPass = Theme.MakeTextBox(352);
        private readonly TextBox txtConfPass = Theme.MakeTextBox(352);

        // ------------------------------------------------------------------

        private void BuildUi()
        {
            AutoScaleMode = AutoScaleMode.Dpi;
            AutoScaleDimensions = new SizeF(96F, 96F);
            Text = "Lost & Found - Bulacan Polytechnic College";
            ClientSize = new Size(1280, 780);
            MinimumSize = new Size(1100, 700);
            StartPosition = FormStartPosition.CenterScreen;
            BackColor = Theme.Surface;

            BuildHeader();
            BuildContentViews();
            BuildSidebar();

            // status strip
            var status = new Panel { Dock = DockStyle.Bottom, Height = 30, BackColor = Color.White };
            lblToast.Dock = DockStyle.Fill;
            lblToast.TextAlign = ContentAlignment.MiddleLeft;
            lblToast.Padding = new Padding(16, 0, 0, 0);
            lblToast.ForeColor = Theme.Primary;
            lblToast.Font = Theme.Body(9.5f, FontStyle.Bold);
            lblToast.UseMnemonic = false;
            status.Controls.Add(lblToast);
            toastTimer.Tick += (s, e) => { lblToast.Text = ""; toastTimer.Stop(); };

            // Dock order: the control added last is docked first.
            Controls.Add(content);
            Controls.Add(sidebarPanel);
            Controls.Add(status);
            Controls.Add(header);
        }

        private readonly Panel sidebarPanel = new Panel();

        // ------------------------------------------------------------------
        // Header: project title is the headline, school name the smaller line.
        // ------------------------------------------------------------------

        private void BuildHeader()
        {
            header.Dock = DockStyle.Top;
            header.Height = 78;
            header.BackColor = Theme.Primary;

            var logo = new PictureBox
            {
                Image = Properties.Resources.e010249b12c608141e27e869b389025d,
                SizeMode = PictureBoxSizeMode.Zoom,
                Size = new Size(54, 54),
                Location = new Point(20, 12),
                BackColor = Color.Transparent
            };

            var title = new Label
            {
                Text = "LOST & FOUND",
                UseMnemonic = false,
                AutoSize = true,
                Font = Theme.Body(21f, FontStyle.Bold),
                ForeColor = Color.White,
                BackColor = Color.Transparent,
                Location = new Point(86, 8)
            };
            var school = new Label
            {
                Text = "Bulacan Polytechnic College",
                AutoSize = true,
                Font = Theme.Body(10f),
                ForeColor = Theme.Accent,
                BackColor = Color.Transparent,
                Location = new Point(89, 47)
            };

            picAvatar.Size = new Size(46, 46);
            picAvatar.SizeMode = PictureBoxSizeMode.Zoom;
            picAvatar.Cursor = Cursors.Hand;
            MakeCircle(picAvatar);
            picAvatar.Click += (s, e) => ShowView(viewProfile, navProfile);

            lblUserName.AutoSize = false;
            lblUserName.Size = new Size(240, 22);
            lblUserName.TextAlign = ContentAlignment.MiddleRight;
            lblUserName.Font = Theme.Body(10.5f, FontStyle.Bold);
            lblUserName.ForeColor = Color.White;
            lblUserName.UseMnemonic = false;

            lblUserRole.AutoSize = false;
            lblUserRole.Size = new Size(240, 20);
            lblUserRole.TextAlign = ContentAlignment.MiddleRight;
            lblUserRole.Font = Theme.Body(9f);
            lblUserRole.ForeColor = Color.FromArgb(200, 225, 200);

            btnLogout = Theme.MakeButton("LOG OUT", PrimaryDarkButton, Color.White, 96, 36);
            btnLogout.FlatAppearance.BorderSize = 1;
            btnLogout.FlatAppearance.BorderColor = Color.FromArgb(90, 150, 95);
            btnLogout.Click += btnLogout_Click;

            header.Controls.AddRange(new Control[] { logo, title, school, picAvatar, lblUserName, lblUserRole, btnLogout });

            header.Resize += (s, e) => LayoutHeader();
            LayoutHeader();
        }

        private static readonly Color PrimaryDarkButton = Color.FromArgb(22, 78, 28);

        private void LayoutHeader()
        {
            btnLogout.Location = new Point(header.ClientSize.Width - 20 - btnLogout.Width, 21);
            picAvatar.Location = new Point(btnLogout.Left - 16 - picAvatar.Width, 16);
            lblUserName.Location = new Point(picAvatar.Left - 12 - lblUserName.Width, 17);
            lblUserRole.Location = new Point(picAvatar.Left - 12 - lblUserRole.Width, 39);
        }

        // ------------------------------------------------------------------
        // Sidebar
        // ------------------------------------------------------------------

        private Button MakeNav(string text, int index)
        {
            var b = new Button
            {
                Text = text,
                UseMnemonic = false,
                FlatStyle = FlatStyle.Flat,
                TextAlign = ContentAlignment.MiddleLeft,
                Padding = new Padding(22, 0, 0, 0),
                Size = new Size(219, 46),
                Location = new Point(0, 20 + index * 50),
                BackColor = Color.White,
                ForeColor = Theme.TextDark,
                Font = Theme.Body(10.5f),
                Cursor = Cursors.Hand,
                UseVisualStyleBackColor = false
            };
            b.FlatAppearance.BorderSize = 0;
            b.FlatAppearance.MouseOverBackColor = Theme.PrimaryLight;
            return b;
        }

        private void BuildSidebar()
        {
            sidebarPanel.Dock = DockStyle.Left;
            sidebarPanel.Width = 220;
            sidebarPanel.BackColor = Color.White;

            sidebarPanel.Controls.Add(new Panel { Dock = DockStyle.Right, Width = 1, BackColor = Theme.Border });

            int i = 0;
            navItems = MakeNav("Lost Items", i++);
            navMap[navItems] = viewItems;
            navItems.Click += (s, e) => ShowView(viewItems, navItems);
            sidebarPanel.Controls.Add(navItems);

            if (IsAdmin)
            {
                navClaims = MakeNav("Claim Requests", i++);
                navMap[navClaims] = viewClaims;
                navClaims.Click += (s, e) => ShowView(viewClaims, navClaims);
                sidebarPanel.Controls.Add(navClaims);

                navUsers = MakeNav("Users", i++);
                navMap[navUsers] = viewUsers;
                navUsers.Click += (s, e) => ShowView(viewUsers, navUsers);
                sidebarPanel.Controls.Add(navUsers);
            }
            else
            {
                navClaims = MakeNav("My Claims", i++);
                navMap[navClaims] = viewMyClaims;
                navClaims.Click += (s, e) => ShowView(viewMyClaims, navClaims);
                sidebarPanel.Controls.Add(navClaims);
            }

            navProfile = MakeNav("My Profile", i++);
            navMap[navProfile] = viewProfile;
            navProfile.Click += (s, e) => ShowView(viewProfile, navProfile);
            sidebarPanel.Controls.Add(navProfile);
        }

        // ------------------------------------------------------------------
        // Views
        // ------------------------------------------------------------------

        private void BuildContentViews()
        {
            content.Dock = DockStyle.Fill;
            content.BackColor = Theme.Surface;
            content.Padding = new Padding(22, 18, 22, 10);

            foreach (Panel v in new[] { viewItems, viewClaims, viewMyClaims, viewUsers, viewProfile })
            {
                v.Dock = DockStyle.Fill;
                v.Visible = false;
                v.BackColor = Theme.Surface;
                content.Controls.Add(v);
            }

            BuildItemsView();
            if (IsAdmin)
            {
                BuildClaimsView();
                BuildUsersView();
            }
            else
            {
                BuildMyClaimsView();
            }
            BuildProfileView();
        }

        private static Panel Spacer(int width) => new Panel { Dock = DockStyle.Right, Width = width, BackColor = Color.Transparent };

        private static void RightAlign(Panel toolbar, Control c)
        {
            toolbar.Resize += (s, e) => c.Left = toolbar.ClientSize.Width - c.Width;
        }

        private static Label AddField(FlowLayoutPanel flow, string caption)
        {
            var cap = Theme.MakeLabel(caption.ToUpperInvariant(), 8f, FontStyle.Bold, Theme.TextMuted);
            cap.Margin = new Padding(0, 12, 0, 0);
            var val = Theme.MakeLabel("", 10f, FontStyle.Regular, Theme.TextDark);
            val.MaximumSize = new Size(290, 0);
            val.Margin = new Padding(0, 2, 0, 0);
            flow.Controls.Add(cap);
            flow.Controls.Add(val);
            return val;
        }

        private static void SetupPhotoBox(PictureBox pb, Size size, string placeholder)
        {
            pb.Size = size;
            pb.SizeMode = PictureBoxSizeMode.Zoom;
            pb.BackColor = Theme.Surface;
            pb.Margin = new Padding(0, 0, 0, 10);
            pb.Cursor = Cursors.Hand;
            pb.Paint += (s, e) =>
            {
                if (pb.Image != null) return;
                using (var br = new SolidBrush(Theme.TextMuted))
                using (var fmt = new StringFormat { Alignment = StringAlignment.Center, LineAlignment = StringAlignment.Center })
                    e.Graphics.DrawString(placeholder, Theme.Body(9.5f), br, new RectangleF(0, 0, pb.Width, pb.Height), fmt);
            };
        }

        private static void SetupEmptyLabel(Label l, string text)
        {
            l.Text = text;
            l.Dock = DockStyle.Fill;
            l.TextAlign = ContentAlignment.MiddleCenter;
            l.Font = Theme.Body(10.5f);
            l.ForeColor = Theme.TextMuted;
            l.UseMnemonic = false;
        }

        // ---------------- Items ----------------

        private void BuildItemsView()
        {
            var toolbar = new Panel { Dock = DockStyle.Top, Height = 56 };

            txtSearch.PlaceholderText = "Search name, description, location...";
            txtSearch.Location = new Point(0, 10);
            txtSearch.TextChanged += (s, e) => { ApplyItemFilter(); SelectFirstIfNone(); ShowItemDetails(); };

            cboCategory.Items.Add("All categories");
            cboCategory.Items.AddRange(Categories.All);
            cboCategory.SelectedIndex = 0;
            cboCategory.Location = new Point(312, 10);
            cboCategory.SelectedIndexChanged += (s, e) => { ApplyItemFilter(); SelectFirstIfNone(); ShowItemDetails(); };

            toolbar.Controls.Add(txtSearch);
            toolbar.Controls.Add(cboCategory);

            int next = 504;
            if (IsAdmin)
            {
                cboStatus.SelectedIndex = 0;
                cboStatus.Location = new Point(504, 10);
                cboStatus.SelectedIndexChanged += (s, e) => { ApplyItemFilter(); SelectFirstIfNone(); ShowItemDetails(); };
                toolbar.Controls.Add(cboStatus);
                next = 706;

                var btnAdd = Theme.MakeButton("+  ADD FOUND ITEM", Theme.Primary, Color.White, 180, 38);
                btnAdd.Click += btnAddItem_Click;
                btnAdd.Top = 5;
                btnAdd.Left = 600;
                toolbar.Controls.Add(btnAdd);
                RightAlign(toolbar, btnAdd);
            }

            lblCount.Location = new Point(next, 15);
            toolbar.Controls.Add(lblCount);

            // grid
            Theme.StyleGrid(dgvItems);
            dgvItems.Columns.Add(Theme.Col("ItemName", "Item", 30));
            dgvItems.Columns.Add(Theme.Col("CategoryName", "Category", 18));
            dgvItems.Columns.Add(Theme.Col("LocationFound", "Found at", 22));
            dgvItems.Columns.Add(Theme.Col("DateFound", "Date found", 15, "MMM d, yyyy"));
            dgvItems.Columns.Add(Theme.Col("StatusDisplay", "Status", 12));
            dgvItems.Dock = DockStyle.Fill;
            dgvItems.SelectionChanged += (s, e) => ShowItemDetails();
            dgvItems.CellFormatting += (s, e) => ColorStatusCell(dgvItems, e, "StatusDisplay");

            // detail card
            var card = new RoundedPanel { Dock = DockStyle.Right, Width = 340, Radius = 12 };

            SetupPhotoBox(picItem, new Size(290, 210), "No photo");
            picItem.DoubleClick += (s, e) => PhotoViewer.Show(this, picItem.Image, lblDName.Text);

            pnlItemFields.Dock = DockStyle.Fill;
            pnlItemFields.FlowDirection = FlowDirection.TopDown;
            pnlItemFields.WrapContents = false;
            pnlItemFields.AutoScroll = true;
            pnlItemFields.Padding = new Padding(16, 16, 8, 8);
            pnlItemFields.BackColor = Color.White;

            lblDName.MaximumSize = new Size(290, 0);
            lblDStatus.Margin = new Padding(0, 6, 0, 0);
            lblDStatus.Padding = new Padding(0, 3, 0, 3);

            pnlItemFields.Controls.Add(picItem);
            pnlItemFields.Controls.Add(lblDName);
            pnlItemFields.Controls.Add(lblDStatus);
            lblDCategory = AddField(pnlItemFields, "Category");
            lblDLocation = AddField(pnlItemFields, "Found at");
            lblDDate = AddField(pnlItemFields, "Date found");
            lblDFoundBy = AddField(pnlItemFields, "Found by");
            lblDContact = AddField(pnlItemFields, "Contact / kept at");
            lblDDescription = AddField(pnlItemFields, "Description");

            SetupEmptyLabel(lblNoSelection, "Select an item to see its details.");

            pnlItemButtons.Dock = DockStyle.Bottom;
            pnlItemButtons.Height = 66;
            pnlItemButtons.BackColor = Color.White;

            if (IsAdmin)
            {
                var btnEdit = Theme.MakeOutlineButton("Edit item", 148, 40);
                btnEdit.Location = new Point(16, 12);
                btnEdit.Click += btnEditItem_Click;

                btnArchive = Theme.MakeButton("Archive", Theme.Warning, Color.White, 148, 40);
                btnArchive.Location = new Point(176, 12);
                btnArchive.Click += btnArchive_Click;

                pnlItemButtons.Controls.AddRange(new Control[] { btnEdit, btnArchive });
            }
            else
            {
                btnClaim = Theme.MakeButton("THIS IS MINE - CLAIM IT", Theme.Primary, Color.White, 308, 42);
                btnClaim.Location = new Point(16, 12);
                btnClaim.Click += btnClaim_Click;
                pnlItemButtons.Controls.Add(btnClaim);
            }

            card.Controls.Add(pnlItemFields);
            card.Controls.Add(lblNoSelection);
            card.Controls.Add(pnlItemButtons);

            viewItems.Controls.Add(dgvItems);
            viewItems.Controls.Add(Spacer(16));
            viewItems.Controls.Add(card);
            viewItems.Controls.Add(toolbar);
        }

        private void SelectFirstIfNone()
        {
            if (dgvItems.Rows.Count > 0 && dgvItems.CurrentRow == null)
            {
                dgvItems.CurrentCell = dgvItems.Rows[0].Cells[0];
                dgvItems.Rows[0].Selected = true;
            }
        }

        // ---------------- Claim requests (admin) ----------------

        private void BuildClaimsView()
        {
            var toolbar = new Panel { Dock = DockStyle.Top, Height = 56 };

            txtClaimSearch.PlaceholderText = "Search item or claimant...";
            txtClaimSearch.Location = new Point(0, 10);
            txtClaimSearch.TextChanged += (s, e) => { ApplyClaimFilter(); ShowClaimDetails(); };

            cboClaimStatus.SelectedIndex = 0;
            cboClaimStatus.Location = new Point(312, 10);
            cboClaimStatus.SelectedIndexChanged += (s, e) => { ApplyClaimFilter(); ShowClaimDetails(); };

            toolbar.Controls.Add(txtClaimSearch);
            toolbar.Controls.Add(cboClaimStatus);

            Theme.StyleGrid(dgvClaims);
            dgvClaims.Columns.Add(Theme.Col("ItemName", "Item", 30));
            dgvClaims.Columns.Add(Theme.Col("FullName", "Claimant", 28));
            dgvClaims.Columns.Add(Theme.Col("RequestDate", "Submitted", 24, "MMM d, yyyy"));
            dgvClaims.Columns.Add(Theme.Col("RequestStatus", "Status", 16));
            dgvClaims.Dock = DockStyle.Fill;
            dgvClaims.SelectionChanged += (s, e) => ShowClaimDetails();
            dgvClaims.CellFormatting += (s, e) => ColorStatusCell(dgvClaims, e, "RequestStatus");

            var card = new RoundedPanel { Dock = DockStyle.Right, Width = 380, Radius = 12 };

            pnlClaimFields.Dock = DockStyle.Fill;
            pnlClaimFields.FlowDirection = FlowDirection.TopDown;
            pnlClaimFields.WrapContents = false;
            pnlClaimFields.AutoScroll = true;
            pnlClaimFields.Padding = new Padding(16, 16, 8, 8);
            pnlClaimFields.BackColor = Color.White;

            SetupPhotoBox(picClaimItem, new Size(158, 150), "No item photo");
            SetupPhotoBox(picClaimProof, new Size(158, 150), "No proof photo");
            picClaimItem.Margin = new Padding(0, 0, 8, 0);
            picClaimProof.Margin = new Padding(0);
            picClaimItem.DoubleClick += (s, e) => PhotoViewer.Show(this, picClaimItem.Image, "Item photo");
            picClaimProof.DoubleClick += (s, e) => PhotoViewer.Show(this, picClaimProof.Image, "Claim proof photo");

            var photoRow = new FlowLayoutPanel
            {
                FlowDirection = FlowDirection.LeftToRight,
                WrapContents = false,
                AutoSize = true,
                Margin = new Padding(0, 0, 0, 2),
                BackColor = Color.White
            };
            photoRow.Controls.Add(picClaimItem);
            photoRow.Controls.Add(picClaimProof);

            var capRow = new Panel { Size = new Size(324, 20), Margin = new Padding(0), BackColor = Color.White };
            var capA = Theme.MakeLabel("Item photo", 8.5f, FontStyle.Regular, Theme.TextMuted);
            capA.Location = new Point(0, 0);
            var capB = Theme.MakeLabel("Claimant's proof (double-click to enlarge)", 8.5f, FontStyle.Regular, Theme.TextMuted);
            capB.Location = new Point(166, 0);
            capB.AutoSize = false;
            capB.Size = new Size(160, 20);
            capB.Text = "Claim proof";
            capRow.Controls.Add(capA);
            capRow.Controls.Add(capB);

            lblCItem.MaximumSize = new Size(320, 0);
            lblCItem.Margin = new Padding(0, 8, 0, 0);
            lblCStatus.Margin = new Padding(0, 6, 0, 0);
            lblCStatus.Padding = new Padding(0, 3, 0, 3);

            pnlClaimFields.Controls.Add(photoRow);
            pnlClaimFields.Controls.Add(capRow);
            pnlClaimFields.Controls.Add(lblCItem);
            pnlClaimFields.Controls.Add(lblCStatus);
            lblCClaimant = AddField(pnlClaimFields, "Claimant");
            lblCContact = AddField(pnlClaimFields, "Contact");
            lblCDate = AddField(pnlClaimFields, "Submitted");
            lblCDetails = AddField(pnlClaimFields, "Proof details");
            foreach (var l in new[] { lblCClaimant, lblCContact, lblCDate, lblCDetails })
                l.MaximumSize = new Size(320, 0);

            SetupEmptyLabel(lblNoClaim, "No claim selected.");

            pnlClaimButtons.Dock = DockStyle.Bottom;
            pnlClaimButtons.Height = 66;
            pnlClaimButtons.BackColor = Color.White;

            btnApprove = Theme.MakeButton("APPROVE", Theme.Primary, Color.White, 166, 42);
            btnApprove.Location = new Point(16, 12);
            btnApprove.Click += (s, e) => ProcessSelectedClaim("Approved");
            btnReject = Theme.MakeButton("REJECT", Theme.Danger, Color.White, 166, 42);
            btnReject.Location = new Point(194, 12);
            btnReject.Click += (s, e) => ProcessSelectedClaim("Rejected");
            pnlClaimButtons.Controls.AddRange(new Control[] { btnApprove, btnReject });

            card.Controls.Add(pnlClaimFields);
            card.Controls.Add(lblNoClaim);
            card.Controls.Add(pnlClaimButtons);

            viewClaims.Controls.Add(dgvClaims);
            viewClaims.Controls.Add(Spacer(16));
            viewClaims.Controls.Add(card);
            viewClaims.Controls.Add(toolbar);
        }

        // ---------------- My claims (user) ----------------

        private void BuildMyClaimsView()
        {
            var intro = Theme.MakeLabel(
                "Your claim requests. When a claim is approved, collect the item at the place shown under \"Collect at\".",
                10f, FontStyle.Regular, Theme.TextMuted);
            var introPanel = new Panel { Dock = DockStyle.Top, Height = 44 };
            intro.Location = new Point(0, 8);
            introPanel.Controls.Add(intro);

            Theme.StyleGrid(dgvMyClaims);
            dgvMyClaims.Columns.Add(Theme.Col("ItemName", "Item", 25));
            dgvMyClaims.Columns.Add(Theme.Col("RequestDate", "Submitted", 18, "MMM d, yyyy"));
            dgvMyClaims.Columns.Add(Theme.Col("RequestStatus", "Status", 14));
            dgvMyClaims.Columns.Add(Theme.Col("HeldAt", "Collect at", 25));
            dgvMyClaims.Columns.Add(Theme.Col("ClaimDetails", "What you told us", 40));
            dgvMyClaims.Dock = DockStyle.Fill;
            dgvMyClaims.CellFormatting += (s, e) => ColorStatusCell(dgvMyClaims, e, "RequestStatus");

            lblMyClaimsEmpty.Text = "You haven't submitted any claims yet. Find your item under Lost Items and press \"This is mine\".";
            lblMyClaimsEmpty.Dock = DockStyle.Top;
            lblMyClaimsEmpty.Height = 50;
            lblMyClaimsEmpty.TextAlign = ContentAlignment.MiddleLeft;
            lblMyClaimsEmpty.Font = Theme.Body(10.5f);
            lblMyClaimsEmpty.ForeColor = Theme.TextMuted;
            lblMyClaimsEmpty.UseMnemonic = false;
            lblMyClaimsEmpty.Visible = false;

            viewMyClaims.Controls.Add(dgvMyClaims);
            viewMyClaims.Controls.Add(lblMyClaimsEmpty);
            viewMyClaims.Controls.Add(introPanel);
        }

        // ---------------- Users (admin) ----------------

        private void BuildUsersView()
        {
            var toolbar = new Panel { Dock = DockStyle.Top, Height = 56 };

            txtUserSearch.PlaceholderText = "Search name or username...";
            txtUserSearch.Location = new Point(0, 10);
            txtUserSearch.TextChanged += (s, e) => { ApplyUserFilter(); UpdateUserButtons(); };
            toolbar.Controls.Add(txtUserSearch);

            btnActive = Theme.MakeButton("Deactivate", Theme.Danger, Color.White, 150, 38);
            btnActive.Top = 5;
            btnActive.Click += btnActive_Click;

            btnRole = Theme.MakeButton("Promote to Admin", Theme.Primary, Color.White, 170, 38);
            btnRole.Top = 5;
            btnRole.Click += btnRole_Click;

            toolbar.Controls.Add(btnActive);
            toolbar.Controls.Add(btnRole);
            toolbar.Resize += (s, e) =>
            {
                btnActive.Left = toolbar.ClientSize.Width - btnActive.Width;
                btnRole.Left = btnActive.Left - 10 - btnRole.Width;
            };

            Theme.StyleGrid(dgvUsers);
            dgvUsers.Columns.Add(Theme.Col("FullName", "Name", 26));
            dgvUsers.Columns.Add(Theme.Col("Username", "Username", 18));
            dgvUsers.Columns.Add(Theme.Col("UserRole", "Role", 12));
            dgvUsers.Columns.Add(Theme.Col("AccountStatus", "Status", 14));
            dgvUsers.Columns.Add(Theme.Col("ContactNumber", "Contact", 16));
            dgvUsers.Columns.Add(Theme.Col("Email", "Email", 24));
            dgvUsers.Dock = DockStyle.Fill;
            dgvUsers.SelectionChanged += (s, e) => UpdateUserButtons();
            dgvUsers.CellFormatting += (s, e) => ColorStatusCell(dgvUsers, e, "AccountStatus");

            viewUsers.Controls.Add(dgvUsers);
            viewUsers.Controls.Add(toolbar);
        }

        // ---------------- Profile ----------------

        private void BuildProfileView()
        {
            viewProfile.AutoScroll = true;

            var cardProfile = new RoundedPanel { Size = new Size(460, 580), Location = new Point(0, 0), Radius = 12 };

            picProfile.Size = new Size(110, 110);
            picProfile.SizeMode = PictureBoxSizeMode.Zoom;
            picProfile.Location = new Point(24, 24);
            picProfile.Cursor = Cursors.Hand;
            MakeCircle(picProfile);
            picProfile.DoubleClick += (s, e) => PhotoViewer.Show(this, picProfile.Image, "Profile photo");

            var btnAvatar = Theme.MakeOutlineButton("Change photo...", 150, 36);
            btnAvatar.Location = new Point(156, 40);
            btnAvatar.Click += btnChangeAvatar_Click;

            var avatarNote = Theme.MakeLabel("Press Save profile to keep it.", 8.5f, FontStyle.Regular, Theme.TextMuted);
            avatarNote.Location = new Point(158, 82);

            cardProfile.Controls.Add(picProfile);
            cardProfile.Controls.Add(btnAvatar);
            cardProfile.Controls.Add(avatarNote);

            int y = 156;
            AddProfileField(cardProfile, "Full name", txtPFullName, ref y);
            AddProfileField(cardProfile, "Username", txtPUsername, ref y);
            AddProfileField(cardProfile, "Role", txtPRole, ref y);
            AddProfileField(cardProfile, "Email", txtPEmail, ref y);
            AddProfileField(cardProfile, "Contact number", txtPContact, ref y);
            txtPFullName.MaxLength = 80;
            txtPEmail.MaxLength = 110;
            txtPContact.MaxLength = 38;
            txtPUsername.ReadOnly = true;
            txtPRole.ReadOnly = true;
            txtPUsername.BackColor = Theme.Surface;
            txtPRole.BackColor = Theme.Surface;

            var btnSave = Theme.MakeButton("SAVE PROFILE", Theme.Primary, Color.White, 412, 42);
            btnSave.Location = new Point(24, y + 6);
            btnSave.Click += btnSaveProfile_Click;
            cardProfile.Controls.Add(btnSave);

            // password card
            var cardPass = new RoundedPanel { Size = new Size(400, 360), Location = new Point(480, 0), Radius = 12 };

            var title = Theme.MakeLabel("Change password", 13f, FontStyle.Bold, Theme.TextDark);
            title.Location = new Point(24, 20);
            var hint = Theme.MakeLabel("At least 8 characters with letters and numbers.", 9f, FontStyle.Regular, Theme.TextMuted);
            hint.Location = new Point(24, 50);
            cardPass.Controls.Add(title);
            cardPass.Controls.Add(hint);

            int py = 84;
            foreach (var tb in new[] { txtCurPass, txtNewPass, txtConfPass }) { tb.UseSystemPasswordChar = true; tb.MaxLength = 128; }
            AddProfileField(cardPass, "Current password", txtCurPass, ref py);
            AddProfileField(cardPass, "New password", txtNewPass, ref py);
            AddProfileField(cardPass, "Confirm new password", txtConfPass, ref py);

            var btnPass = Theme.MakeButton("UPDATE PASSWORD", Theme.PrimaryDark, Color.White, 352, 42);
            btnPass.Location = new Point(24, py + 6);
            btnPass.Click += btnChangePassword_Click;
            cardPass.Controls.Add(btnPass);

            viewProfile.Controls.Add(cardProfile);
            viewProfile.Controls.Add(cardPass);
        }

        private static void AddProfileField(Control parent, string caption, TextBox tb, ref int y)
        {
            var lbl = Theme.MakeLabel(caption, 9.5f, FontStyle.Bold, Theme.TextDark);
            lbl.Location = new Point(24, y);
            tb.Location = new Point(24, y + 22);
            parent.Controls.Add(lbl);
            parent.Controls.Add(tb);
            y += 66;
        }
    }
}
