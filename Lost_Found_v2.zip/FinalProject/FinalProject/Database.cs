using System;
using System.Data;
using System.Data.OleDb;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.IO;

namespace FinalProject
{
    public static class Database
    {
        public static readonly string DBpATH = ResolveDbPath();

        private static readonly string connectionString =
            @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" +
            DBpATH +
            ";Persist Security Info=False;";

        private static string ResolveDbPath()
        {
            // Development layout: bin\Debug\net10.0-windows\ -> project folder.
            string dev = Path.GetFullPath(Path.Combine(
                AppDomain.CurrentDomain.BaseDirectory, @"..\..\..\FinalProject.accdb"));

            if (File.Exists(dev)) return dev;

            // Fallback: database sitting next to the .exe (published build).
            return Path.GetFullPath(Path.Combine(
                AppDomain.CurrentDomain.BaseDirectory, "FinalProject.accdb"));
        }

        public static OleDbConnection GetConnection()
        {
            return new OleDbConnection(connectionString);
        }

        /// <summary>
        /// Adds the columns the newer features need. Safe to run on every start:
        /// existing data is never touched and columns are only added when missing.
        /// </summary>
        public static void EnsureSchema()
        {
            using (OleDbConnection con = GetConnection())
            {
                con.Open();

                // Users: profile
                AddColumn(con, "Users", "Email", "TEXT(120)");
                AddColumn(con, "Users", "ContactNumber", "TEXT(40)");
                AddColumn(con, "Users", "PhotoPath", "TEXT(100)");

                // LostItems: category, photo, finder/contact, archive
                // ItemType: "Found" (an item someone handed in) or "Lost" (an item an owner is looking for)
                if (AddColumn(con, "LostItems", "ItemType", "TEXT(10)"))
                    Exec(con, "UPDATE LostItems SET ItemType = 'Found'");
                AddColumn(con, "LostItems", "Category", "TEXT(50)");
                AddColumn(con, "LostItems", "PhotoPath", "TEXT(100)");
                AddColumn(con, "LostItems", "FoundBy", "TEXT(120)");
                AddColumn(con, "LostItems", "ContactInfo", "TEXT(200)");
                if (AddColumn(con, "LostItems", "IsArchived", "YESNO"))
                    Exec(con, "UPDATE LostItems SET IsArchived = False");
                AddColumn(con, "LostItems", "DateArchived", "DATETIME");

                // ClaimRequests: proof photo + claimant contact
                AddColumn(con, "ClaimRequests", "ProofPhotoPath", "TEXT(100)");
                AddColumn(con, "ClaimRequests", "ContactInfo", "TEXT(120)");

                // ItemReports: lost/found reports submitted by users, waiting for an admin to approve.
                // Approving a report creates the LostItems row automatically.
                if (!TableExists(con, "ItemReports"))
                    Exec(con,
                        "CREATE TABLE ItemReports (" +
                        "ReportID COUNTER PRIMARY KEY, UserID LONG, ItemType TEXT(10), ItemName TEXT(100), " +
                        "Category TEXT(50), [Description] MEMO, LocationName TEXT(100), EventDate DATETIME, " +
                        "ReporterName TEXT(100), ContactInfo TEXT(200), PhotoPath TEXT(100), " +
                        "ReportStatus TEXT(20), SubmittedAt DATETIME, ReviewedAt DATETIME)");
            }
        }

        private static bool TableExists(OleDbConnection con, string table)
        {
            using (DataTable dt = con.GetSchema("Tables", new string?[] { null, null, table, "TABLE" }))
                return dt.Rows.Count > 0;
        }

        private static bool ColumnExists(OleDbConnection con, string table, string column)
        {
            using (DataTable dt = con.GetSchema("Columns", new string?[] { null, null, table, null }))
            {
                foreach (DataRow r in dt.Rows)
                {
                    if (string.Equals(Convert.ToString(r["COLUMN_NAME"]), column,
                        StringComparison.OrdinalIgnoreCase))
                        return true;
                }
            }
            return false;
        }

        private static bool AddColumn(OleDbConnection con, string table, string column, string type)
        {
            if (ColumnExists(con, table, column)) return false;
            Exec(con, $"ALTER TABLE [{table}] ADD COLUMN [{column}] {type}");
            return true;
        }

        private static void Exec(OleDbConnection con, string sql)
        {
            using (var cmd = new OleDbCommand(sql, con))
                cmd.ExecuteNonQuery();
        }
    }

    /// <summary>
    /// Stores photos as files (not inside the database) in a Photos folder beside the .accdb.
    /// Only a generated file name goes into the database. Every upload is validated, resized
    /// and re-encoded as JPEG, which also strips EXIF/GPS metadata.
    /// </summary>
    public static class PhotoStore
    {
        public const long MaxSourceBytes = 10L * 1024 * 1024;
        private const int MaxDimension = 1280;

        public static string Folder
        {
            get
            {
                string dir = Path.Combine(
                    Path.GetDirectoryName(Database.DBpATH) ?? AppDomain.CurrentDomain.BaseDirectory,
                    "Photos");
                Directory.CreateDirectory(dir);
                return dir;
            }
        }

        public static string? PickPhoto(IWin32Window owner)
        {
            using (var dlg = new OpenFileDialog())
            {
                dlg.Title = "Choose a photo";
                dlg.Filter = "Images (*.jpg;*.jpeg;*.png;*.bmp;*.gif)|*.jpg;*.jpeg;*.png;*.bmp;*.gif";
                dlg.CheckFileExists = true;
                return dlg.ShowDialog(owner) == DialogResult.OK ? dlg.FileName : null;
            }
        }

        /// <summary>Loads a picked file for previewing (no lock on the file). Returns null if invalid.</summary>
        public static Image? LoadForPreview(string path, out string? error)
        {
            error = null;
            try
            {
                var info = new FileInfo(path);
                if (!info.Exists) { error = "File not found."; return null; }
                if (info.Length > MaxSourceBytes) { error = "Photo is too large (max 10 MB)."; return null; }

                using (var fs = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.Read))
                using (var img = Image.FromStream(fs))
                    return new Bitmap(img);
            }
            catch
            {
                error = "That file is not a valid image.";
                return null;
            }
        }

        /// <summary>Saves a picked image into the Photos folder and returns the stored file name.</summary>
        public static string Save(string sourcePath)
        {
            Image? src = LoadForPreview(sourcePath, out string? error);
            if (src == null) throw new InvalidOperationException(error ?? "Invalid image.");

            using (src)
            {
                float scale = Math.Min(1f, (float)MaxDimension / Math.Max(src.Width, src.Height));
                int w = Math.Max(1, (int)(src.Width * scale));
                int h = Math.Max(1, (int)(src.Height * scale));

                using (var bmp = new Bitmap(w, h))
                {
                    using (Graphics g = Graphics.FromImage(bmp))
                    {
                        g.Clear(Color.White);
                        g.InterpolationMode = InterpolationMode.HighQualityBicubic;
                        g.DrawImage(src, 0, 0, w, h);
                    }

                    string name = Guid.NewGuid().ToString("N") + ".jpg";
                    bmp.Save(Path.Combine(Folder, name), ImageFormat.Jpeg);
                    return name;
                }
            }
        }

        /// <summary>Loads a stored photo by file name. Returns null if missing or unreadable.</summary>
        public static Image? Load(string? storedName)
        {
            if (string.IsNullOrWhiteSpace(storedName)) return null;

            try
            {
                // GetFileName blocks any path tricks such as "..\..\something".
                string path = Path.Combine(Folder, Path.GetFileName(storedName));
                if (!File.Exists(path)) return null;

                using (var fs = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.Read))
                using (var img = Image.FromStream(fs))
                    return new Bitmap(img);
            }
            catch
            {
                return null;
            }
        }

        public static void TryDelete(string? storedName)
        {
            if (string.IsNullOrWhiteSpace(storedName)) return;
            try
            {
                string path = Path.Combine(Folder, Path.GetFileName(storedName));
                if (File.Exists(path)) File.Delete(path);
            }
            catch { /* leftover file is harmless */ }
        }
    }
}
