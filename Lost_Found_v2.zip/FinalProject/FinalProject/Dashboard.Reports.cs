using System;
using System.Data;
using System.Windows.Forms;

namespace FinalProject
{
    // Lost/found reports: users submit, the admin approves (item is posted automatically) or rejects.
    public partial class Dashboard
    {
        private Button navReports = null!;
        private readonly Panel viewReports = new Panel();      // admin
        private readonly Panel viewMyReports = new Panel();    // user

        // ---- admin: review reports ----
        private readonly TextBox txtReportSearch = Theme.MakeTextBox(300);
        private readonly ComboBox cboReportStatus = Theme.MakeCombo(160, "Pending", "Approved", "Rejected", "All");
        private readonly DataGridView dgvReports = new DataGridView();
        private readonly PictureBox picReport = new PictureBox();
        private readonly FlowLayoutPanel pnlReportFields = new FlowLayoutPanel();
        private readonly Label lblNoReport = new Label();
        private readonly Panel pnlReportButtons = new Panel();
        private readonly Label lblRName = Theme.MakeLabel("", 13f, FontStyle.Bold, Theme.TextDark);
        private readonly Label lblRStatus = Theme.MakeLabel("", 8.5f, FontStyle.Bold, Color.White);
        private Label lblRType = null!, lblRCategory = null!, lblRLocation = null!, lblRDate = null!,
                      lblRBy = null!, lblRContact = null!, lblRSubmitted = null!, lblRDescription = null!;
        private Button btnReportApprove = null!, btnReportReject = null!;

        private DataTable? reportsTable;
        private DataView? reportsView;
        private Image? reportImage;

        // ---- user: my reports ----
        private readonly DataGridView dgvMyReports = new DataGridView();
        private readonly Label lblMyReportsEmpty = new Label();

        // ------------------------------------------------------------------
        // Admin view
        // ------------------------------------------------------------------

        private void BuildReportsView()
        {
            var toolbar = new Panel { Dock = DockStyle.Top, Height = 56 };

            txtReportSearch.PlaceholderText = "Search item or reporter...";
            txtReportSearch.Location = new Point(0, 10);
            txtReportSearch.TextChanged += (s, e) => { ApplyReportFilter(); ShowReportDetails(); };

            cboReportStatus.SelectedIndex = 0;
            cboReportStatus.Location = new Point(312, 10);
            cboReportStatus.SelectedIndexChanged += (s, e) => { ApplyReportFilter(); ShowReportDetails(); };

            toolbar.Controls.Add(txtReportSearch);
            toolbar.Controls.Add(cboReportStatus);

            Theme.StyleGrid(dgvReports);
            dgvReports.Columns.Add(Theme.Col("TypeName", "Type", 11));
            dgvReports.Columns.Add(Theme.Col("ItemName", "Item", 28));
            dgvReports.Columns.Add(Theme.Col("SubmitterName", "Reported by", 25));
            dgvReports.Columns.Add(Theme.Col("SubmittedAt", "Submitted", 20, "MMM d, yyyy"));
            dgvReports.Columns.Add(Theme.Col("ReportStatus", "Status", 14));
            dgvReports.Dock = DockStyle.Fill;
            dgvReports.SelectionChanged += (s, e) => ShowReportDetails();
            dgvReports.CellFormatting += (s, e) => ColorStatusCell(dgvReports, e, "ReportStatus");
            dgvReports.CellFormatting += (s, e) => ColorTypeCell(dgvReports, e);

            var card = new RoundedPanel { Dock = DockStyle.Right, Width = 380, Radius = 12 };

            SetupPhotoBox(picReport, new Size(324, 200), "No photo");
            picReport.DoubleClick += (s, e) => PhotoViewer.Show(this, picReport.Image, lblRName.Text);

            pnlReportFields.Dock = DockStyle.Fill;
            pnlReportFields.FlowDirection = FlowDirection.TopDown;
            pnlReportFields.WrapContents = false;
            pnlReportFields.AutoScroll = true;
            pnlReportFields.Padding = new Padding(16, 16, 8, 8);
            pnlReportFields.BackColor = Color.White;

            lblRName.MaximumSize = new Size(320, 0);
            lblRStatus.Margin = new Padding(0, 6, 0, 0);
            lblRStatus.Padding = new Padding(0, 3, 0, 3);

            pnlReportFields.Controls.Add(picReport);
            pnlReportFields.Controls.Add(lblRName);
            pnlReportFields.Controls.Add(lblRStatus);
            lblRType = AddField(pnlReportFields, "Type");
            lblRCategory = AddField(pnlReportFields, "Category");
            lblRLocation = AddField(pnlReportFields, "Location (found / last seen)");
            lblRDate = AddField(pnlReportFields, "Date (found / lost)");
            lblRBy = AddField(pnlReportFields, "Reported by");
            lblRContact = AddField(pnlReportFields, "Contact");
            lblRSubmitted = AddField(pnlReportFields, "Submitted");
            lblRDescription = AddField(pnlReportFields, "Description");
            foreach (var l in new[] { lblRType, lblRCategory, lblRLocation, lblRDate, lblRBy, lblRContact, lblRSubmitted, lblRDescription })
                l.MaximumSize = new Size(320, 0);

            SetupEmptyLabel(lblNoReport, "No report selected.");

            pnlReportButtons.Dock = DockStyle.Bottom;
            pnlReportButtons.Height = 66;
            pnlReportButtons.BackColor = Color.White;

            btnReportApprove = Theme.MakeButton("APPROVE AND POST", Theme.Primary, Color.White, 184, 42);
            btnReportApprove.Location = new Point(16, 12);
            btnReportApprove.Click += (s, e) => ProcessSelectedReport(true);
            btnReportReject = Theme.MakeButton("REJECT", Theme.Danger, Color.White, 140, 42);
            btnReportReject.Location = new Point(212, 12);
            btnReportReject.Click += (s, e) => ProcessSelectedReport(false);
            pnlReportButtons.Controls.AddRange(new Control[] { btnReportApprove, btnReportReject });

            card.Controls.Add(pnlReportFields);
            card.Controls.Add(lblNoReport);
            card.Controls.Add(pnlReportButtons);

            viewReports.Controls.Add(dgvReports);
            viewReports.Controls.Add(Spacer(16));
            viewReports.Controls.Add(card);
            viewReports.Controls.Add(toolbar);
        }

        private void LoadReports()
        {
            if (!IsAdmin) return;

            try
            {
                int keepId = Selected(dgvReports) is DataRowView cur ? Convert.ToInt32(cur["ReportID"]) : 0;

                reportsTable = Repo.GetAllReports();
                reportsView = new DataView(reportsTable);
                dgvReports.DataSource = reportsView;

                int pending = reportsTable.Select("ReportStatus = 'Pending'").Length;
                navReports.Text = pending > 0 ? "Item Reports  (" + pending + ")" : "Item Reports";

                ApplyReportFilter();

                if (dgvReports.Rows.Count > 0)
                {
                    DataGridViewRow target = dgvReports.Rows[0];
                    foreach (DataGridViewRow row in dgvReports.Rows)
                        if (row.DataBoundItem is DataRowView v && Convert.ToInt32(v["ReportID"]) == keepId) { target = row; break; }
                    dgvReports.CurrentCell = target.Cells[0];
                    target.Selected = true;
                }
                ShowReportDetails();
            }
            catch (Exception ex) { Fail("loading reports", ex); }
        }

        private void ApplyReportFilter()
        {
            if (reportsView == null) return;

            var parts = new List<string>();
            string q = txtReportSearch.Text.Trim();
            if (q.Length > 0)
            {
                string e = Theme.EscapeLike(q);
                parts.Add("(ItemName LIKE '%" + e + "%' OR SubmitterName LIKE '%" + e + "%' OR ReporterName LIKE '%" + e + "%')");
            }

            string status = Convert.ToString(cboReportStatus.SelectedItem) ?? "All";
            if (status != "All") parts.Add("ReportStatus = '" + status + "'");

            try { reportsView.RowFilter = string.Join(" AND ", parts); }
            catch (EvaluateException) { reportsView.RowFilter = ""; }
        }

        private void ShowReportDetails()
        {
            DataRowView? r = Selected(dgvReports);

            Image? old = reportImage;
            reportImage = null;
            picReport.Image = null;
            old?.Dispose();

            bool has = r != null;
            pnlReportFields.Visible = has;
            lblNoReport.Visible = !has;
            pnlReportButtons.Visible = has;
            if (r == null) return;

            reportImage = PhotoStore.Load(S(r, "PhotoPath"));
            picReport.Image = reportImage;
            picReport.Invalidate();

            string status = S(r, "ReportStatus");
            lblRName.Text = S(r, "ItemName");
            lblRStatus.Text = "  " + status.ToUpperInvariant() + "  ";
            lblRStatus.BackColor = StatusColor(status);

            lblRType.Text = S(r, "TypeName");
            lblRCategory.Text = S(r, "CategoryName");
            lblRLocation.Text = S(r, "LocationName");
            lblRDate.Text = r["EventDate"] is DateTime d ? d.ToString("MMMM d, yyyy") : "";
            lblRBy.Text = S(r, "ReporterName").Length > 0 ? S(r, "ReporterName") : S(r, "SubmitterName");
            lblRContact.Text = S(r, "ContactInfo").Length > 0 ? S(r, "ContactInfo") : "Not provided";
            lblRSubmitted.Text = (r["SubmittedAt"] is DateTime s ? s.ToString("MMM d, yyyy  h:mm tt") : "")
                                 + "\nby " + S(r, "SubmitterName") + "  (" + S(r, "Username") + ")";
            lblRDescription.Text = S(r, "Description");

            bool pending = status == "Pending";
            btnReportApprove.Enabled = pending;
            btnReportReject.Enabled = pending;
        }

        private void ProcessSelectedReport(bool approve)
        {
            DataRowView? r = Selected(dgvReports);
            if (!IsAdmin || r == null) return;

            string name = S(r, "ItemName");
            string msg = approve
                ? "Post \"" + name + "\" as a " + S(r, "TypeName").ToLowerInvariant() + " item?\n\n" +
                  "It will appear in the items list using the details the user submitted. You can still edit it afterwards."
                : "Reject the report for \"" + name + "\"?";
            if (!Theme.Confirm(this, msg, approve ? "Approve report" : "Reject report")) return;

            string rejectedPhoto = S(r, "PhotoPath");

            try
            {
                string? err = Repo.ProcessReport(userId, Convert.ToInt32(r["ReportID"]), approve);
                if (err != null)
                {
                    Theme.Warn(this, err);
                }
                else
                {
                    Toast(approve ? "Report approved and posted." : "Report rejected.");
                }

                LoadReports();
                LoadItems();

                // A rejected report's photo is no longer needed.
                if (err == null && !approve) PhotoStore.TryDelete(rejectedPhoto);
            }
            catch (Exception ex) { Fail("processing the report", ex); }
        }

        // ------------------------------------------------------------------
        // User view
        // ------------------------------------------------------------------

        private void BuildMyReportsView()
        {
            var top = new Panel { Dock = DockStyle.Top, Height = 56 };

            var intro = Theme.MakeLabel(
                "Report an item you lost or found. An administrator reviews it and, once approved, it is posted.",
                10f, FontStyle.Regular, Theme.TextMuted);
            intro.Location = new Point(0, 18);
            top.Controls.Add(intro);

            var btnNew = Theme.MakeButton("+  REPORT AN ITEM", Theme.Primary, Color.White, 190, 38);
            btnNew.Top = 8;
            btnNew.Click += btnNewReport_Click;
            top.Controls.Add(btnNew);
            RightAlign(top, btnNew);

            Theme.StyleGrid(dgvMyReports);
            dgvMyReports.Columns.Add(Theme.Col("TypeName", "Type", 12));
            dgvMyReports.Columns.Add(Theme.Col("ItemName", "Item", 36));
            dgvMyReports.Columns.Add(Theme.Col("EventDate", "Date lost / found", 20, "MMM d, yyyy"));
            dgvMyReports.Columns.Add(Theme.Col("SubmittedAt", "Submitted", 20, "MMM d, yyyy"));
            dgvMyReports.Columns.Add(Theme.Col("ReportStatus", "Status", 14));
            dgvMyReports.Dock = DockStyle.Fill;
            dgvMyReports.CellFormatting += (s, e) => ColorStatusCell(dgvMyReports, e, "ReportStatus");
            dgvMyReports.CellFormatting += (s, e) => ColorTypeCell(dgvMyReports, e);

            lblMyReportsEmpty.Text = "You haven't reported anything yet. Press \"Report an item\" to get started.";
            lblMyReportsEmpty.Dock = DockStyle.Top;
            lblMyReportsEmpty.Height = 50;
            lblMyReportsEmpty.TextAlign = ContentAlignment.MiddleLeft;
            lblMyReportsEmpty.Font = Theme.Body(10.5f);
            lblMyReportsEmpty.ForeColor = Theme.TextMuted;
            lblMyReportsEmpty.UseMnemonic = false;
            lblMyReportsEmpty.Visible = false;

            viewMyReports.Controls.Add(dgvMyReports);
            viewMyReports.Controls.Add(lblMyReportsEmpty);
            viewMyReports.Controls.Add(top);
        }

        private void LoadMyReports()
        {
            if (IsAdmin) return;

            try
            {
                DataTable t = Repo.GetReportsForUser(userId);
                var old = dgvMyReports.DataSource as DataTable;
                dgvMyReports.DataSource = t;
                old?.Dispose();
                lblMyReportsEmpty.Visible = t.Rows.Count == 0;
            }
            catch (Exception ex) { Fail("loading your reports", ex); }
        }

        private void btnNewReport_Click(object? sender, EventArgs e)
        {
            if (IsAdmin) return;

            string contact = profile.ContactNumber.Length > 0 ? profile.ContactNumber : profile.Email;
            var seed = new ItemData
            {
                FoundBy = profile.FullName.Length > 0 ? profile.FullName : fullName,
                ContactInfo = contact
            };

            using (var dlg = new ItemDialog(seed, true))
            {
                if (dlg.ShowDialog(this) != DialogResult.OK) return;

                try
                {
                    string? err = Repo.SubmitReport(userId, dlg.Result);
                    if (err != null)
                    {
                        PhotoStore.TryDelete(dlg.Result.PhotoPath);
                        Theme.Warn(this, err);
                        return;
                    }

                    Toast("Report submitted. An administrator will review it.");
                    LoadMyReports();
                }
                catch (Exception ex)
                {
                    PhotoStore.TryDelete(dlg.Result.PhotoPath);
                    Fail("submitting the report", ex);
                }
            }
        }
    }
}
