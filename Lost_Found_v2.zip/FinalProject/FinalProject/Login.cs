using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace FinalProject
{
    public partial class Login : Form
    {
        // Failed-attempt tracking is keyed by the typed name whether or not the account exists,
        // so the lockout message never reveals which usernames are real.
        private static readonly Dictionary<string, (int count, DateTime until)> attempts = new();
        private const int MaxAttempts = 5;
        private static readonly TimeSpan LockTime = TimeSpan.FromMinutes(2);

        // Verified against when the username doesn't exist, so response time doesn't leak it either.
        private static readonly string dummyHash = PasswordHelper.HashPassword("not-a-real-password-1");

        private BackdropPanel backdrop = null!;
        private RoundedPanel card = null!;
        private TextBox txtUsername = null!;
        private TextBox txtPassword = null!;
        private CheckBox chkShow = null!;
        private Button btnSignin = null!;
        private LinkLabel linkRegister = null!;

        public Login()
        {
            BuildUi();
        }

        private void BuildUi()
        {
            AutoScaleMode = AutoScaleMode.Dpi;
            AutoScaleDimensions = new SizeF(96F, 96F);
            Text = "Lost & Found - Sign in";
            ClientSize = new Size(1000, 660);
            MinimumSize = new Size(820, 620);
            StartPosition = FormStartPosition.CenterScreen;

            backdrop = new BackdropPanel { Dock = DockStyle.Fill };
            Controls.Add(backdrop);

            card = new RoundedPanel { Size = new Size(400, 500), Radius = 16 };
            backdrop.Controls.Add(card);

            var logo = new PictureBox
            {
                Image = Properties.Resources.e010249b12c608141e27e869b389025d,
                SizeMode = PictureBoxSizeMode.Zoom,
                Size = new Size(72, 72),
                Location = new Point((card.Width - 72) / 2, 26),
                BackColor = Color.Transparent
            };
            card.Controls.Add(logo);

            // Project title is the headline; school name is the smaller line underneath.
            var title = new Label
            {
                Text = "LOST & FOUND",
                Font = Theme.Body(22f, FontStyle.Bold),
                ForeColor = Theme.Primary,
                AutoSize = false,
                UseMnemonic = false,
                TextAlign = ContentAlignment.MiddleCenter,
                Size = new Size(card.Width, 40),
                Location = new Point(0, 106)
            };
            var school = new Label
            {
                Text = "Bulacan Polytechnic College",
                Font = Theme.Body(10f),
                ForeColor = Theme.TextMuted,
                AutoSize = false,
                UseMnemonic = false,
                TextAlign = ContentAlignment.MiddleCenter,
                Size = new Size(card.Width, 22),
                Location = new Point(0, 146)
            };
            card.Controls.Add(title);
            card.Controls.Add(school);

            int x = 40, w = card.Width - 80;

            var lblUser = Theme.MakeLabel("Username", 9.5f, FontStyle.Bold, Theme.TextDark);
            lblUser.Location = new Point(x, 188);
            txtUsername = Theme.MakeTextBox(w);
            txtUsername.Location = new Point(x, 212);
            txtUsername.MaxLength = 50;

            var lblPass = Theme.MakeLabel("Password", 9.5f, FontStyle.Bold, Theme.TextDark);
            lblPass.Location = new Point(x, 254);
            txtPassword = Theme.MakeTextBox(w);
            txtPassword.Location = new Point(x, 278);
            txtPassword.UseSystemPasswordChar = true;
            txtPassword.MaxLength = 128;

            chkShow = new CheckBox
            {
                Text = "Show password",
                AutoSize = true,
                Font = Theme.Body(9f),
                ForeColor = Theme.TextMuted,
                Location = new Point(x, 314)
            };
            chkShow.CheckedChanged += (s, e) => txtPassword.UseSystemPasswordChar = !chkShow.Checked;

            btnSignin = Theme.MakeButton("SIGN IN", Theme.Primary, Color.White, w, 44);
            btnSignin.Location = new Point(x, 352);
            btnSignin.Click += btnSignin_Click;

            linkRegister = new LinkLabel
            {
                Text = "New here? Create an account",
                AutoSize = false,
                UseMnemonic = false,
                TextAlign = ContentAlignment.MiddleCenter,
                Size = new Size(card.Width, 24),
                Location = new Point(0, 416),
                Font = Theme.Body(9.5f),
                LinkColor = Theme.Primary,
                ActiveLinkColor = Theme.PrimaryDark,
                BackColor = Color.Transparent
            };
            linkRegister.LinkClicked += linkRegister_LinkClicked;

            card.Controls.AddRange(new Control[] { lblUser, txtUsername, lblPass, txtPassword, chkShow, btnSignin, linkRegister });

            AcceptButton = btnSignin;
            backdrop.Resize += (s, e) => CenterCard();
            Shown += (s, e) => { CenterCard(); txtUsername.Focus(); };
        }

        private void CenterCard()
        {
            card.Location = new Point(
                Math.Max(0, (backdrop.ClientSize.Width - card.Width) / 2),
                Math.Max(0, (backdrop.ClientSize.Height - card.Height) / 2));
        }

        private void btnSignin_Click(object? sender, EventArgs e)
        {
            string username = txtUsername.Text.Trim();
            string password = txtPassword.Text;

            if (username.Length == 0 || password.Length == 0)
            {
                Theme.Warn(this, "Please enter your username and password.");
                return;
            }

            string key = username.ToLowerInvariant();

            if (attempts.TryGetValue(key, out var a) && a.until > DateTime.Now)
            {
                int secs = (int)Math.Ceiling((a.until - DateTime.Now).TotalSeconds);
                Theme.Warn(this, $"Too many failed attempts. Please wait {secs} seconds and try again.");
                return;
            }

            try
            {
                LoginRecord? rec = Repo.FindLogin(username);

                // Always do one hash verification, even for unknown usernames.
                bool ok = PasswordHelper.VerifyPassword(password, rec?.Hash ?? dummyHash) && rec != null;

                if (!ok)
                {
                    RegisterFailure(key);
                    Theme.Warn(this, "Invalid username or password.", "Sign in failed");
                    txtPassword.Clear();
                    txtPassword.Focus();
                    return;
                }

                if (rec!.Inactive)
                {
                    Theme.Warn(this, "This account is unavailable. Please contact an administrator.", "Sign in failed");
                    return;
                }

                attempts.Remove(key);

                if (PasswordHelper.NeedsRehash(rec.Hash))
                    Repo.UpgradePasswordHash(rec.UserID, password);

                Hide();
                using (var dashboard = new Dashboard(rec.UserID, rec.FullName, rec.Role))
                {
                    dashboard.ShowDialog();
                }

                txtPassword.Clear();
                chkShow.Checked = false;
                Show();
                txtUsername.Focus();
            }
            catch (Exception)
            {
                // No exception text on the login screen: it can expose table names, paths or SQL.
                Theme.Error(this, "Sign in is unavailable right now. Please try again later.");
            }
        }

        private static void RegisterFailure(string key)
        {
            attempts.TryGetValue(key, out var a);
            if (a.until != DateTime.MinValue && a.until <= DateTime.Now) a = (0, DateTime.MinValue);

            int count = a.count + 1;
            if (count >= MaxAttempts)
                attempts[key] = (0, DateTime.Now + LockTime);
            else
                attempts[key] = (count, DateTime.MinValue);
        }

        private void linkRegister_LinkClicked(object? sender, LinkLabelLinkClickedEventArgs e)
        {
            using (var registerForm = new Register())
            {
                registerForm.ShowDialog(this);
            }
        }
    }
}
