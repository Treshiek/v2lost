using System;
using System.Windows.Forms;

namespace FinalProject
{
    internal static class Program
    {
        [STAThread]
        static void Main()
        {
            ApplicationConfiguration.Initialize();

            try
            {
                Database.EnsureSchema();
            }
            catch (Exception)
            {
                MessageBox.Show(
                    "The application could not open its database.\n\n" +
                    "Make sure FinalProject.accdb is in place and the Microsoft Access Database Engine (ACE OLEDB) is installed.",
                    "Lost & Found", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            Application.Run(new Login());
        }
    }
}
