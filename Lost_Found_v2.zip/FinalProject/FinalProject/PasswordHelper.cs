using System;
using System.Security.Cryptography;

namespace FinalProject
{
    public static class PasswordHelper
    {
        // Current format: PBKDF2v2$iterations$salt$hash  (HMAC-SHA256)
        // Legacy format:  PBKDF2$iterations$salt$hash    (HMAC-SHA1) - still accepted, upgraded on next login.
        private const int CurrentIterations = 210000;
        private const string CurrentTag = "PBKDF2v2";

        public static string HashPassword(string password)
        {
            byte[] salt = RandomNumberGenerator.GetBytes(16);
            byte[] hash = Rfc2898DeriveBytes.Pbkdf2(
                password, salt, CurrentIterations, HashAlgorithmName.SHA256, 32);

            return $"{CurrentTag}${CurrentIterations}${Convert.ToBase64String(salt)}${Convert.ToBase64String(hash)}";
        }

        public static bool VerifyPassword(string password, string storedHash)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(storedHash)) return false;

                string[] parts = storedHash.Split('$');
                if (parts.Length != 4) return false;

                HashAlgorithmName alg;
                if (parts[0] == CurrentTag) alg = HashAlgorithmName.SHA256;
                else if (parts[0] == "PBKDF2") alg = HashAlgorithmName.SHA1;
                else return false;

                int iterations = int.Parse(parts[1]);
                byte[] salt = Convert.FromBase64String(parts[2]);
                byte[] original = Convert.FromBase64String(parts[3]);

                byte[] test = Rfc2898DeriveBytes.Pbkdf2(password, salt, iterations, alg, original.Length);
                return CryptographicOperations.FixedTimeEquals(test, original);
            }
            catch
            {
                return false;
            }
        }

        public static bool NeedsRehash(string storedHash)
        {
            return string.IsNullOrEmpty(storedHash) || !storedHash.StartsWith(CurrentTag + "$");
        }

        /// <summary>Returns an error message if the password is too weak, otherwise null.</summary>
        public static string? Validate(string password)
        {
            if (password.Length < 8) return "Password must be at least 8 characters long.";
            if (password.Length > 128) return "Password is too long (max 128 characters).";

            bool letter = false, digit = false;
            foreach (char c in password)
            {
                if (char.IsLetter(c)) letter = true;
                else if (char.IsDigit(c)) digit = true;
            }

            if (!letter || !digit) return "Password must contain at least one letter and one number.";
            return null;
        }
    }
}
