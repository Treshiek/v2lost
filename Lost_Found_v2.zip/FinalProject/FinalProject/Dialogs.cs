using System;
using System.Windows.Forms;

namespace FinalProject
{
    /// <summary>Base for small modal forms so they all look alike.</summary>
    internal class DialogBase : Form
    {
        protected DialogBase(string title, Size clientSize)
        {
            AutoScaleMode = AutoScaleMode.Dpi;
            AutoScaleDimensions = new SizeF(96F, 96F);
            Text = title;
            ClientSize = clientSize;
            FormBorderStyle = FormBorderStyle.FixedDialog;
            MaximizeBox = false;
            MinimizeBox = false;
            ShowInTaskbar = false;
            StartPosition = FormStartPosition.CenterParent;
            BackColor = Color.White;
            Font = Theme.Body(10f);
        }

        protected static PictureBox MakePhotoBox(int w, int h)
        {
            return new PictureBox
            {
                Size = new Size(w, h),
                SizeMode = PictureBoxSizeMode.Zoom,
                BackColor = Theme.Surface,
                BorderStyle = BorderStyle.FixedSingle
            };
        }
    }

    /// <summary>Add / edit an item (admin).</summary>
    internal class ItemDialog : DialogBase
    {
        private readonly ComboBox cboType = Theme.MakeCombo(400, ItemTypes.All);
        private readonly TextBox txtName = Theme.MakeTextBox(400);
        private readonly ComboBox cboCategory = Theme.MakeCombo(400, Categories.All);
        private readonly TextBox txtLocation = Theme.MakeTextBox(400);
        private readonly DateTimePicker dtpDate = new DateTimePicker();
        private readonly TextBox txtFoundBy = Theme.MakeTextBox(400);
        private readonly TextBox txtContact = Theme.MakeTextBox(400);
        private readonly TextBox txtDescription = Theme.MakeTextBox(400, true, 90);
        private readonly PictureBox pbPhoto = MakePhotoBox(300, 300);

        private string? currentPhoto;       // name already stored (edit mode)
        private string? pendingSource;      // newly picked file, saved when OK is pressed
        private Image? previewImage;

        public ItemData Result { get; private set; } = new ItemData();
        public string? OriginalPhoto { get; }

        private readonly bool reportMode;

        /// <param name="reportMode">True when a regular user is reporting an item for admin review.</param>
        public ItemDialog(ItemData? existing, bool reportMode = false)
            : base(reportMode ? "Report an item" : existing == null ? "Add item" : "Edit item", new Size(780, 664))
        {
            this.reportMode = reportMode;
            OriginalPhoto = existing?.PhotoPath;
            currentPhoto = existing?.PhotoPath;

            int x = 24, y = 20;
            AddRow("Type * (Found = handed in, Lost = owner is looking for it)", cboType, x, ref y);
            AddRow("Item name *", txtName, x, ref y);
            AddRow("Category *", cboCategory, x, ref y);
            AddRow("Location * (where it was found / last seen)", txtLocation, x, ref y);

            var lblDate = Theme.MakeLabel("Date * (found / lost)", 9.5f, FontStyle.Bold);
            lblDate.Location = new Point(x, y);
            Controls.Add(lblDate);
            dtpDate.Format = DateTimePickerFormat.Short;
            dtpDate.MaxDate = DateTime.Today;
            dtpDate.Value = DateTime.Today;
            dtpDate.Font = Theme.Body(10.5f);
            dtpDate.Width = 200;
            dtpDate.Location = new Point(x, y + 22);
            Controls.Add(dtpDate);
            y += 62;

            AddRow("Reported by (name of finder / owner)", txtFoundBy, x, ref y);
            AddRow(reportMode ? "Your contact (phone / email) *" : "Contact info / kept at (e.g. Guard House)", txtContact, x, ref y);
            AddRow("Description *", txtDescription, x, ref y, 90);

            txtName.MaxLength = 100;
            txtLocation.MaxLength = 100;
            txtFoundBy.MaxLength = 100;
            txtContact.MaxLength = 190;

            // Right column: photo
            var lblPhoto = Theme.MakeLabel("Item photo", 9.5f, FontStyle.Bold);
            lblPhoto.Location = new Point(460, 20);
            Controls.Add(lblPhoto);

            pbPhoto.Location = new Point(460, 42);
            Controls.Add(pbPhoto);

            var btnChoose = Theme.MakeOutlineButton("Choose photo...", 145, 34);
            btnChoose.Location = new Point(460, 354);
            btnChoose.Click += (s, e) => ChoosePhoto();
            var btnRemove = Theme.MakeOutlineButton("Remove", 145, 34);
            btnRemove.Location = new Point(615, 354);
            btnRemove.Click += (s, e) => { pendingSource = null; currentPhoto = null; ShowPreview(null); };
            Controls.AddRange(new Control[] { btnChoose, btnRemove });

            var note = Theme.MakeLabel("Photos are resized and stripped of location data.", 8.5f, FontStyle.Regular, Theme.TextMuted);
            note.Location = new Point(460, 396);
            Controls.Add(note);

            var btnSave = Theme.MakeButton(reportMode ? "SUBMIT REPORT" : existing == null ? "ADD ITEM" : "SAVE CHANGES", Theme.Primary, Color.White, 170, 42);
            btnSave.Location = new Point(ClientSize.Width - 24 - 170, ClientSize.Height - 62);
            btnSave.Click += (s, e) => Save();
            var btnCancel = Theme.MakeOutlineButton("Cancel", 110, 42);
            btnCancel.Location = new Point(btnSave.Left - 120, btnSave.Top);
            btnCancel.DialogResult = DialogResult.Cancel;
            Controls.AddRange(new Control[] { btnSave, btnCancel });
            AcceptButton = btnSave;
            CancelButton = btnCancel;

            if (reportMode)
            {
                var review = Theme.MakeLabel("An administrator will review your report before it is posted.", 8.5f, FontStyle.Regular, Theme.TextMuted);
                review.Location = new Point(24, ClientSize.Height - 50);
                Controls.Add(review);
            }

            if (existing != null)
            {
                cboType.SelectedItem = existing.ItemType == ItemTypes.Lost ? ItemTypes.Lost : ItemTypes.Found;
                txtName.Text = existing.Name;
                cboCategory.SelectedItem = Array.IndexOf(Categories.All, existing.Category) >= 0 ? existing.Category : "Other";
                txtLocation.Text = existing.Location;
                dtpDate.Value = existing.DateFound > dtpDate.MaxDate ? dtpDate.MaxDate
                              : existing.DateFound < dtpDate.MinDate ? dtpDate.MinDate : existing.DateFound;
                txtFoundBy.Text = existing.FoundBy;
                txtContact.Text = existing.ContactInfo;
                txtDescription.Text = existing.Description;
                ShowPreview(PhotoStore.Load(existing.PhotoPath));
            }
            else
            {
                cboType.SelectedIndex = 0;
                cboCategory.SelectedIndex = 0;
            }
        }

        private void AddRow(string caption, Control input, int x, ref int y, int height = 0)
        {
            var lbl = Theme.MakeLabel(caption, 9.5f, FontStyle.Bold);
            lbl.Location = new Point(x, y);
            Controls.Add(lbl);

            input.Location = new Point(x, y + 22);
            Controls.Add(input);
            y += (height > 0 ? height + 22 + 14 : 62);
        }

        private void ChoosePhoto()
        {
            string? path = PhotoStore.PickPhoto(this);
            if (path == null) return;

            Image? img = PhotoStore.LoadForPreview(path, out string? error);
            if (img == null)
            {
                Theme.Warn(this, error ?? "Could not load that image.");
                return;
            }

            pendingSource = path;
            ShowPreview(img);
        }

        private void ShowPreview(Image? img)
        {
            pbPhoto.Image = null;
            previewImage?.Dispose();
            previewImage = img;
            pbPhoto.Image = img;
        }

        private void Save()
        {
            if (txtName.Text.Trim().Length == 0 || txtLocation.Text.Trim().Length == 0 ||
                txtDescription.Text.Trim().Length == 0 || cboCategory.SelectedItem == null)
            {
                Theme.Warn(this, "Please fill in the item name, category, location and description.");
                return;
            }

            if (reportMode && txtContact.Text.Trim().Length == 0)
            {
                Theme.Warn(this, "Please leave a contact number or email so the admin can reach you.");
                return;
            }

            string? photo = currentPhoto;
            if (pendingSource != null)
            {
                try { photo = PhotoStore.Save(pendingSource); }
                catch (Exception ex)
                {
                    Theme.Warn(this, ex is InvalidOperationException ? ex.Message : "The photo could not be saved.");
                    return;
                }
            }

            Result = new ItemData
            {
                Name = txtName.Text.Trim(),
                ItemType = Convert.ToString(cboType.SelectedItem) ?? ItemTypes.Found,
                Category = Convert.ToString(cboCategory.SelectedItem) ?? "Other",
                Location = txtLocation.Text.Trim(),
                DateFound = dtpDate.Value.Date,
                FoundBy = txtFoundBy.Text.Trim(),
                ContactInfo = txtContact.Text.Trim(),
                Description = txtDescription.Text.Trim(),
                PhotoPath = photo
            };
            DialogResult = DialogResult.OK;
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing) { pbPhoto.Image = null; previewImage?.Dispose(); }
            base.Dispose(disposing);
        }
    }

    /// <summary>Claim an item: describe it, leave contact info, optionally attach a proof photo.</summary>
    internal class ClaimDialog : DialogBase
    {
        private readonly TextBox txtDetails = Theme.MakeTextBox(430, true, 110);
        private readonly TextBox txtContact = Theme.MakeTextBox(430);
        private readonly PictureBox pbProof = MakePhotoBox(200, 200);
        private string? pendingSource;
        private Image? previewImage;

        public string Details { get; private set; } = "";
        public string Contact { get; private set; } = "";
        public string? ProofPhotoName { get; private set; }

        public ClaimDialog(string itemName, string defaultContact)
            : base("Claim item", new Size(490, 640))
        {
            int x = 28;

            var head = Theme.MakeLabel("Claiming: " + itemName, 12f, FontStyle.Bold, Theme.Primary);
            head.MaximumSize = new Size(430, 0);
            head.Location = new Point(x, 20);
            Controls.Add(head);

            var hint = Theme.MakeLabel("Describe things only the owner would know (marks, contents, serial number, lock screen...).",
                9f, FontStyle.Regular, Theme.TextMuted);
            hint.MaximumSize = new Size(430, 0);
            hint.Location = new Point(x, 56);
            Controls.Add(hint);

            var lblDetails = Theme.MakeLabel("Proof of ownership details *", 9.5f, FontStyle.Bold);
            lblDetails.Location = new Point(x, 98);
            Controls.Add(lblDetails);
            txtDetails.Location = new Point(x, 120);
            Controls.Add(txtDetails);

            var lblContact = Theme.MakeLabel("Your contact number or email *", 9.5f, FontStyle.Bold);
            lblContact.Location = new Point(x, 246);
            Controls.Add(lblContact);
            txtContact.Location = new Point(x, 268);
            txtContact.MaxLength = 110;
            txtContact.Text = defaultContact;
            Controls.Add(txtContact);

            var lblProof = Theme.MakeLabel("Photo proof (optional, e.g. an older photo of you with the item)", 9.5f, FontStyle.Bold);
            lblProof.MaximumSize = new Size(430, 0);
            lblProof.Location = new Point(x, 312);
            Controls.Add(lblProof);

            pbProof.Location = new Point(x, 338);
            Controls.Add(pbProof);

            var btnChoose = Theme.MakeOutlineButton("Choose photo...", 150, 34);
            btnChoose.Location = new Point(x + 216, 338);
            btnChoose.Click += (s, e) => ChoosePhoto();
            var btnRemove = Theme.MakeOutlineButton("Remove", 150, 34);
            btnRemove.Location = new Point(x + 216, 380);
            btnRemove.Click += (s, e) => { pendingSource = null; ShowPreview(null); };
            Controls.AddRange(new Control[] { btnChoose, btnRemove });

            var btnSubmit = Theme.MakeButton("SUBMIT CLAIM", Theme.Primary, Color.White, 170, 42);
            btnSubmit.Location = new Point(ClientSize.Width - 28 - 170, ClientSize.Height - 62);
            btnSubmit.Click += (s, e) => Submit();
            var btnCancel = Theme.MakeOutlineButton("Cancel", 110, 42);
            btnCancel.Location = new Point(btnSubmit.Left - 120, btnSubmit.Top);
            btnCancel.DialogResult = DialogResult.Cancel;
            Controls.AddRange(new Control[] { btnSubmit, btnCancel });
            CancelButton = btnCancel;
        }

        private void ChoosePhoto()
        {
            string? path = PhotoStore.PickPhoto(this);
            if (path == null) return;

            Image? img = PhotoStore.LoadForPreview(path, out string? error);
            if (img == null)
            {
                Theme.Warn(this, error ?? "Could not load that image.");
                return;
            }

            pendingSource = path;
            ShowPreview(img);
        }

        private void ShowPreview(Image? img)
        {
            pbProof.Image = null;
            previewImage?.Dispose();
            previewImage = img;
            pbProof.Image = img;
        }

        private void Submit()
        {
            if (txtDetails.Text.Trim().Length < 10)
            {
                Theme.Warn(this, "Please describe the item in a bit more detail (at least 10 characters).");
                return;
            }

            if (txtContact.Text.Trim().Length == 0)
            {
                Theme.Warn(this, "Please leave a contact number or email so the admin can reach you.");
                return;
            }

            if (pendingSource != null)
            {
                try { ProofPhotoName = PhotoStore.Save(pendingSource); }
                catch (Exception ex)
                {
                    Theme.Warn(this, ex is InvalidOperationException ? ex.Message : "The photo could not be saved.");
                    return;
                }
            }

            Details = txtDetails.Text.Trim();
            Contact = txtContact.Text.Trim();
            DialogResult = DialogResult.OK;
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing) { pbProof.Image = null; previewImage?.Dispose(); }
            base.Dispose(disposing);
        }
    }
}
