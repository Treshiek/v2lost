using System;
using System.Drawing.Drawing2D;
using System.Text;

namespace FinalProject
{
    /// <summary>Shared colors, fonts and small control factories so every screen looks the same.</summary>
    internal static class Theme
    {
        public static readonly Color Primary = Color.FromArgb(27, 94, 32);
        public static readonly Color PrimaryDark = Color.FromArgb(18, 66, 24);
        public static readonly Color PrimaryLight = Color.FromArgb(232, 243, 230);
        public static readonly Color Accent = Color.FromArgb(250, 204, 21);
        public static readonly Color Surface = Color.FromArgb(243, 246, 241);
        public static readonly Color Card = Color.White;
        public static readonly Color TextDark = Color.FromArgb(30, 41, 34);
        public static readonly Color TextMuted = Color.FromArgb(104, 116, 108);
        public static readonly Color Border = Color.FromArgb(214, 222, 211);
        public static readonly Color Danger = Color.FromArgb(178, 48, 48);
        public static readonly Color Warning = Color.FromArgb(217, 119, 6);
        public static readonly Color Neutral = Color.FromArgb(96, 108, 100);

        public static Font Body(float size = 10f, FontStyle style = FontStyle.Regular) => new Font("Segoe UI", size, style);

        public static Label MakeLabel(string text, float size = 10f, FontStyle style = FontStyle.Regular, Color? color = null)
        {
            return new Label
            {
                Text = text,
                AutoSize = true,
                UseMnemonic = false,
                Font = Body(size, style),
                ForeColor = color ?? TextDark,
                BackColor = Color.Transparent
            };
        }

        public static Button MakeButton(string text, Color back, Color? fore = null, int width = 140, int height = 38)
        {
            var b = new Button
            {
                Text = text,
                Width = width,
                Height = height,
                FlatStyle = FlatStyle.Flat,
                BackColor = back,
                ForeColor = fore ?? Color.White,
                Font = Body(9.5f, FontStyle.Bold),
                Cursor = Cursors.Hand,
                UseVisualStyleBackColor = false
            };
            b.FlatAppearance.BorderSize = 0;
            b.FlatAppearance.MouseOverBackColor = ControlPaint.Light(back, 0.12f);
            b.FlatAppearance.MouseDownBackColor = ControlPaint.Dark(back, 0.05f);
            return b;
        }

        public static Button MakeOutlineButton(string text, int width = 140, int height = 38)
        {
            var b = MakeButton(text, Color.White, TextDark, width, height);
            b.FlatAppearance.BorderSize = 1;
            b.FlatAppearance.BorderColor = Border;
            b.FlatAppearance.MouseOverBackColor = PrimaryLight;
            return b;
        }

        public static TextBox MakeTextBox(int width, bool multiline = false, int height = 0)
        {
            var t = new TextBox
            {
                Width = width,
                Font = Body(10.5f),
                BorderStyle = BorderStyle.FixedSingle,
                BackColor = Color.White,
                ForeColor = TextDark
            };
            if (multiline)
            {
                t.Multiline = true;
                t.ScrollBars = ScrollBars.Vertical;
                t.Height = height > 0 ? height : 80;
            }
            return t;
        }

        public static ComboBox MakeCombo(int width, params string[] items)
        {
            var c = new ComboBox
            {
                Width = width,
                DropDownStyle = ComboBoxStyle.DropDownList,
                FlatStyle = FlatStyle.Flat,
                Font = Body(10f),
                BackColor = Color.White
            };
            c.Items.AddRange(items);
            if (items.Length > 0) c.SelectedIndex = 0;
            return c;
        }

        public static void StyleGrid(DataGridView g)
        {
            g.AllowUserToAddRows = false;
            g.AllowUserToDeleteRows = false;
            g.AllowUserToResizeRows = false;
            g.ReadOnly = true;
            g.MultiSelect = false;
            g.RowHeadersVisible = false;
            g.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            g.AutoGenerateColumns = false;
            g.BackgroundColor = Color.White;
            g.BorderStyle = BorderStyle.None;
            g.CellBorderStyle = DataGridViewCellBorderStyle.SingleHorizontal;
            g.GridColor = Color.FromArgb(232, 237, 230);
            g.EnableHeadersVisualStyles = false;
            g.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.None;
            g.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            g.ColumnHeadersHeight = 40;
            g.ColumnHeadersDefaultCellStyle.BackColor = PrimaryLight;
            g.ColumnHeadersDefaultCellStyle.ForeColor = PrimaryDark;
            g.ColumnHeadersDefaultCellStyle.Font = Body(9.5f, FontStyle.Bold);
            g.ColumnHeadersDefaultCellStyle.Padding = new Padding(8, 0, 0, 0);
            g.ColumnHeadersDefaultCellStyle.SelectionBackColor = PrimaryLight;
            g.ColumnHeadersDefaultCellStyle.SelectionForeColor = PrimaryDark;
            g.DefaultCellStyle.Font = Body(10f);
            g.DefaultCellStyle.ForeColor = TextDark;
            g.DefaultCellStyle.Padding = new Padding(8, 0, 0, 0);
            g.DefaultCellStyle.SelectionBackColor = Color.FromArgb(200, 228, 200);
            g.DefaultCellStyle.SelectionForeColor = TextDark;
            g.RowTemplate.Height = 38;
            g.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
        }

        public static DataGridViewTextBoxColumn Col(string dataProperty, string header, float fillWeight = 100, string? format = null)
        {
            var c = new DataGridViewTextBoxColumn
            {
                DataPropertyName = dataProperty,
                Name = dataProperty,
                HeaderText = header,
                FillWeight = fillWeight,
                SortMode = DataGridViewColumnSortMode.Automatic
            };
            if (format != null) c.DefaultCellStyle.Format = format;
            return c;
        }

        /// <summary>Escapes user text so it is safe inside a DataView.RowFilter LIKE '...' expression.</summary>
        public static string EscapeLike(string s)
        {
            var sb = new StringBuilder();
            foreach (char ch in s)
            {
                switch (ch)
                {
                    case '\'': sb.Append("''"); break;
                    case '[': sb.Append("[[]"); break;
                    case ']': sb.Append("[]]"); break;
                    case '*': sb.Append("[*]"); break;
                    case '%': sb.Append("[%]"); break;
                    default: sb.Append(ch); break;
                }
            }
            return sb.ToString();
        }

        public static void Info(IWin32Window? owner, string text, string title = "Lost & Found")
            => MessageBox.Show(owner, text, title, MessageBoxButtons.OK, MessageBoxIcon.Information);

        public static void Warn(IWin32Window? owner, string text, string title = "Lost & Found")
            => MessageBox.Show(owner, text, title, MessageBoxButtons.OK, MessageBoxIcon.Warning);

        public static void Error(IWin32Window? owner, string text, string title = "Lost & Found")
            => MessageBox.Show(owner, text, title, MessageBoxButtons.OK, MessageBoxIcon.Error);

        public static bool Confirm(IWin32Window? owner, string text, string title = "Please confirm")
            => MessageBox.Show(owner, text, title, MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes;
    }

    /// <summary>
    /// Full-bleed background: the campus photo scaled to "cover", then dimmed so foreground cards stand out.
    /// The dimmed image is cached and only rebuilt on resize.
    /// </summary>
    internal class BackdropPanel : Panel
    {
        private Bitmap? cache;

        public BackdropPanel()
        {
            SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.UserPaint |
                     ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw, true);
            BackColor = Color.FromArgb(14, 40, 18);
        }

        protected override void OnSizeChanged(EventArgs e)
        {
            cache?.Dispose();
            cache = null;
            base.OnSizeChanged(e);
        }

        private void BuildCache()
        {
            if (Width <= 0 || Height <= 0) return;

            cache = new Bitmap(Width, Height);
            using (Graphics g = Graphics.FromImage(cache))
            {
                g.Clear(BackColor);
                Image src = Properties.Resources.BPC;

                float scale = Math.Max((float)Width / src.Width, (float)Height / src.Height);
                float w = src.Width * scale;
                float h = src.Height * scale;
                g.InterpolationMode = InterpolationMode.HighQualityBicubic;
                g.DrawImage(src, (Width - w) / 2f, (Height - h) / 2f, w, h);

                // Dim layer + soft vignette towards the bottom.
                using (var dim = new SolidBrush(Color.FromArgb(185, 8, 28, 12)))
                    g.FillRectangle(dim, 0, 0, Width, Height);

                using (var grad = new LinearGradientBrush(
                    new Rectangle(0, 0, Width, Height),
                    Color.FromArgb(0, 0, 0, 0), Color.FromArgb(120, 0, 0, 0), 90f))
                    g.FillRectangle(grad, 0, 0, Width, Height);
            }
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            if (cache == null) BuildCache();
            if (cache != null) e.Graphics.DrawImageUnscaled(cache, 0, 0);
            else e.Graphics.Clear(BackColor);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing) cache?.Dispose();
            base.Dispose(disposing);
        }
    }

    /// <summary>Opaque panel with rounded corners.</summary>
    internal class RoundedPanel : Panel
    {
        [System.ComponentModel.DesignerSerializationVisibility(System.ComponentModel.DesignerSerializationVisibility.Hidden)]
        public int Radius { get; set; } = 14;

        public RoundedPanel()
        {
            BackColor = Color.White;
        }

        protected override void OnSizeChanged(EventArgs e)
        {
            base.OnSizeChanged(e);
            if (Width <= 0 || Height <= 0) return;

            using (var path = new GraphicsPath())
            {
                int d = Radius * 2;
                path.AddArc(0, 0, d, d, 180, 90);
                path.AddArc(Width - d, 0, d, d, 270, 90);
                path.AddArc(Width - d, Height - d, d, d, 0, 90);
                path.AddArc(0, Height - d, d, d, 90, 90);
                path.CloseFigure();
                Region?.Dispose();
                Region = new Region(path);
            }
        }
    }

    /// <summary>Simple full-size image viewer used when someone double-clicks a photo.</summary>
    internal class PhotoViewer : Form
    {
        public PhotoViewer(Image image, string title)
        {
            Text = title;
            StartPosition = FormStartPosition.CenterParent;
            Size = new Size(820, 640);
            BackColor = Color.FromArgb(20, 24, 21);
            KeyPreview = true;
            KeyDown += (s, e) => { if (e.KeyCode == Keys.Escape) Close(); };

            var pb = new PictureBox
            {
                Dock = DockStyle.Fill,
                SizeMode = PictureBoxSizeMode.Zoom,
                Image = image
            };
            Controls.Add(pb);
        }

        public static void Show(IWin32Window owner, Image? image, string title)
        {
            if (image == null) return;
            using (var viewer = new PhotoViewer(image, title))
                viewer.ShowDialog(owner);
        }
    }
}
