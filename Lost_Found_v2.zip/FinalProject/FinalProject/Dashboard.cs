using System;
using System.Data;
using System.Drawing.Drawing2D;
using System.Drawing.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace FinalProject
{
    public partial class Dashboard : Form
    {
        private static readonly Font BoldCell = Theme.Body(10f, FontStyle.Bold);
        private static readonly Regex EmailRule = new Regex(@"^[^@\s]+@[^@\s]+\.[^@\s]+$", RegexOptions.Compiled);
        private static readonly Regex PhoneRule = new Regex(@"^[0-9+\-\s()]{7,20}$", RegexOptions.Compiled);

        private readonly int userId;
        private string fullName;
        private readonly string role;
        private UserProfile profile = new UserProfile();

        private bool IsAdmin => string.Equals(role, "Admin", StringComparison.OrdinalIgnoreCase);

        public Dashboard(int userID, string fullName, string role)
        {
            this.userId = userID;
            this.fullName = fullName;
            this.role = role;

            BuildUi();

            profile = Repo.GetProfile(userId) ?? new UserProfile { UserID = userId, FullName = fullName, Role = role };
            RefreshHeaderUser();
            RefreshProfileView();

            ShowView(viewItems, navItems);
            if (IsAdmin) LoadReports();   // shows the pending count on the sidebar right away
        }

        // ------------------------------------------------------------------
        // Navigation
        // ------------------------------------------------------------------

        private void ShowView(Panel view, Button nav)
        {
            foreach (var kv in navMap)
            {
                bool active = kv.Key == nav;
                kv.Key.BackColor = active ? Theme.PrimaryLight : Color.White;
                kv.Key.ForeColor = active ? Theme.PrimaryDark : Theme.TextDark;
                kv.Key.Font = Theme.Body(10.5f, active ? FontStyle.Bold : FontStyle.Regular);
                kv.Value.Visible = kv.Value == view;
            }

            // Views reload when opened, so no manual refresh button is needed.
            if (view == viewItems) LoadItems();
            else if (view == viewClaims) LoadClaims();
            else if (view == viewMyClaims) LoadMyClaims();
            else if (view == viewReports) LoadReports();
            else if (view == viewMyReports) LoadMyReports();
            else if (view == viewUsers) LoadUsers();
        }

        private void Toast(string message)
        {
            lblToast.Text = message;
            toastTimer.Stop();
            toastTimer.Start();
        }

        private void Fail(string action, Exception ex)
        {
            // Technical details are not shown to the user.
            Theme.Error(this, $"Sorry, {action} failed. Please try again.");
        }

        private static DataRowView? Selected(DataGridView g) => g.CurrentRow?.DataBoundItem as DataRowView;
        private static string S(DataRowView r, string col) => Convert.ToString(r[col]) ?? "";

        private static Color StatusColor(string s)
        {
            switch (s)
            {
                case "Available":
                case "Approved":
                case "Active": return Color.FromArgb(30, 120, 50);
                case "Pending":
                case "Archived": return Theme.Warning;
                case "Rejected":
                case "Deactivated": return Theme.Danger;
                default: return Theme.Neutral;
            }
        }

        private void ColorTypeCell(DataGridView g, DataGridViewCellFormattingEventArgs e)
        {
            if (e.RowIndex < 0 || e.Value == null) return;
            if (g.Columns[e.ColumnIndex].Name != "TypeName") return;
            bool lost = string.Equals(Convert.ToString(e.Value), ItemTypes.Lost, StringComparison.Ordinal);
            e.CellStyle.ForeColor = lost ? Color.FromArgb(185, 28, 28) : Theme.Primary;
            e.CellStyle.Font = BoldCell;
        }

        private void ColorStatusCell(DataGridView g, DataGridViewCellFormattingEventArgs e, string columnName)
        {
            if (e.RowIndex < 0 || e.Value == null) return;
            if (g.Columns[e.ColumnIndex].Name != columnName) return;
            e.CellStyle.ForeColor = StatusColor(Convert.ToString(e.Value) ?? "");
            e.CellStyle.Font = BoldCell;
        }

        // ------------------------------------------------------------------
        // Avatars
        // ------------------------------------------------------------------

        private static Bitmap InitialsAvatar(string name, int size)
        {
            string initials = "?";
            string[] parts = name.Split(' ', StringSplitOptions.RemoveEmptyEntries);
            if (parts.Length == 1) initials = parts[0].Substring(0, 1).ToUpperInvariant();
            else if (parts.Length > 1)
                initials = (parts[0].Substring(0, 1) + parts[parts.Length - 1].Substring(0, 1)).ToUpperInvariant();

            var bmp = new Bitmap(size, size);
            using (Graphics g = Graphics.FromImage(bmp))
            {
                g.SmoothingMode = SmoothingMode.AntiAlias;
                g.TextRenderingHint = TextRenderingHint.AntiAliasGridFit;
                g.Clear(Theme.PrimaryLight);
                using (var f = new Font("Segoe UI", size * 0.36f, FontStyle.Bold, GraphicsUnit.Pixel))
                using (var br = new SolidBrush(Theme.Primary))
                using (var fmt = new StringFormat { Alignment = StringAlignment.Center, LineAlignment = StringAlignment.Center })
                    g.DrawString(initials, f, br, new RectangleF(0, 0, size, size), fmt);
            }
            return bmp;
        }

        private static void MakeCircle(PictureBox pb)
        {
            using (var gp = new GraphicsPath())
            {
                gp.AddEllipse(0, 0, pb.Width, pb.Height);
                pb.Region = new Region(gp);
            }
        }

        private static void SetAvatar(PictureBox pb, string? photoName, string name)
        {
            Image img = PhotoStore.Load(photoName) ?? InitialsAvatar(name, Math.Max(pb.Width, 64));
            Image? old = pb.Image;
            pb.Image = img;
            old?.Dispose();
        }

        private void RefreshHeaderUser()
        {
            lblUserName.Text = profile.FullName.Length > 0 ? profile.FullName : fullName;
            lblUserRole.Text = IsAdmin ? "Administrator" : "Student / User";
            SetAvatar(picAvatar, profile.PhotoPath, lblUserName.Text);
        }

        // ------------------------------------------------------------------
        // ITEMS
        // ------------------------------------------------------------------

        private DataTable? itemsTable;
        private DataView? itemsView;
        private Image? detailImage;

        private void LoadItems()
        {
            try
            {
                int keepId = Selected(dgvItems) is DataRowView cur ? Convert.ToInt32(cur["ItemID"]) : 0;

                itemsTable = Repo.GetItems(IsAdmin);
                itemsView = new DataView(itemsTable);
                dgvItems.DataSource = itemsView;

                ApplyItemFilter();
                SelectItemById(keepId);
                ShowItemDetails();
            }
            catch (Exception ex) { Fail("loading items", ex); }
        }

        private void ApplyItemFilter()
        {
            if (itemsView == null) return;

            var parts = new List<string>();

            string q = txtSearch.Text.Trim();
            if (q.Length > 0)
            {
                string e = Theme.EscapeLike(q);
                parts.Add("(ItemName LIKE '%" + e + "%' OR [Description] LIKE '%" + e + "%' OR LocationFound LIKE '%" + e +
                          "%' OR FoundBy LIKE '%" + e + "%' OR CategoryName LIKE '%" + e + "%')");
            }

            if (cboType.SelectedIndex > 0)
                parts.Add("TypeName = '" + (Convert.ToString(cboType.SelectedItem) ?? "").Replace("'", "''") + "'");

            if (cboCategory.SelectedIndex > 0)
                parts.Add("CategoryName = '" + (Convert.ToString(cboCategory.SelectedItem) ?? "").Replace("'", "''") + "'");

            if (IsAdmin)
            {
                switch (cboStatus.SelectedIndex)
                {
                    case 0: parts.Add("ArchivedFlag = 0"); break;
                    case 1: parts.Add("ArchivedFlag = 0 AND Status = 'Available'"); break;
                    case 2: parts.Add("ArchivedFlag = 0 AND Status = 'Claimed'"); break;
                    case 3: parts.Add("ArchivedFlag = 1"); break;
                }
            }

            try { itemsView.RowFilter = string.Join(" AND ", parts); }
            catch (EvaluateException) { itemsView.RowFilter = ""; }

            lblCount.Text = itemsView.Count == 1 ? "1 item" : itemsView.Count + " items";
        }

        private void SelectItemById(int id)
        {
            if (dgvItems.Rows.Count == 0) return;

            foreach (DataGridViewRow row in dgvItems.Rows)
            {
                if (row.DataBoundItem is DataRowView v && Convert.ToInt32(v["ItemID"]) == id)
                {
                    dgvItems.CurrentCell = row.Cells[0];
                    row.Selected = true;
                    return;
                }
            }
            dgvItems.CurrentCell = dgvItems.Rows[0].Cells[0];
            dgvItems.Rows[0].Selected = true;
        }

        private void ShowItemDetails()
        {
            DataRowView? r = Selected(dgvItems);

            Image? old = detailImage;
            detailImage = null;
            picItem.Image = null;
            old?.Dispose();

            bool has = r != null;
            pnlItemFields.Visible = has;
            lblNoSelection.Visible = !has;
            pnlItemButtons.Visible = has;
            if (r == null) return;

            detailImage = PhotoStore.Load(S(r, "PhotoPath"));
            picItem.Image = detailImage;
            picItem.Invalidate();

            lblDName.Text = S(r, "ItemName");
            string status = S(r, "StatusDisplay");
            lblDStatus.Text = "  " + status.ToUpperInvariant() + "  ";
            lblDStatus.BackColor = StatusColor(status);

            lblDType.Text = S(r, "TypeName");
            lblDCategory.Text = S(r, "CategoryName");
            lblDLocation.Text = S(r, "LocationFound");
            lblDDate.Text = r["DateFound"] is DateTime d ? d.ToString("MMMM d, yyyy") : "";
            lblDFoundBy.Text = S(r, "FoundBy").Length > 0 ? S(r, "FoundBy") : "Not recorded";
            lblDContact.Text = S(r, "ContactInfo").Length > 0 ? S(r, "ContactInfo") : "Not recorded";
            lblDDescription.Text = S(r, "Description");

            bool archived = Convert.ToInt32(r["ArchivedFlag"]) == 1;
            // Only found items can be claimed; a "Lost" report is an owner looking for something.
            bool available = S(r, "Status") == "Available" && !archived && S(r, "TypeName") != ItemTypes.Lost;

            if (IsAdmin)
            {
                btnArchive.Text = archived ? "Restore" : "Archive";
                btnArchive.BackColor = archived ? Theme.Primary : Theme.Warning;
            }
            else
            {
                btnClaim.Enabled = available;
            }
        }

        private ItemData RowToItemData(DataRowView r)
        {
            return new ItemData
            {
                Name = S(r, "ItemName"),
                ItemType = S(r, "TypeName"),
                Category = S(r, "CategoryName"),
                Description = S(r, "Description"),
                Location = S(r, "LocationFound"),
                DateFound = r["DateFound"] is DateTime d ? d : DateTime.Today,
                FoundBy = S(r, "FoundBy"),
                ContactInfo = S(r, "ContactInfo"),
                PhotoPath = S(r, "PhotoPath").Length > 0 ? S(r, "PhotoPath") : null
            };
        }

        private void btnAddItem_Click(object? sender, EventArgs e)
        {
            if (!IsAdmin) return;

            using (var dlg = new ItemDialog(null))
            {
                if (dlg.ShowDialog(this) != DialogResult.OK) return;

                try
                {
                    string? err = Repo.AddItem(userId, dlg.Result);
                    if (err != null)
                    {
                        PhotoStore.TryDelete(dlg.Result.PhotoPath);
                        Theme.Warn(this, err);
                        return;
                    }
                    Toast("Item added: " + dlg.Result.Name);
                    LoadItems();
                }
                catch (Exception ex)
                {
                    PhotoStore.TryDelete(dlg.Result.PhotoPath);
                    Fail("adding the item", ex);
                }
            }
        }

        private void btnEditItem_Click(object? sender, EventArgs e)
        {
            DataRowView? r = Selected(dgvItems);
            if (!IsAdmin || r == null) return;

            int id = Convert.ToInt32(r["ItemID"]);

            using (var dlg = new ItemDialog(RowToItemData(r)))
            {
                if (dlg.ShowDialog(this) != DialogResult.OK) return;

                try
                {
                    string? err = Repo.UpdateItem(userId, id, dlg.Result);
                    if (err != null)
                    {
                        if (dlg.Result.PhotoPath != dlg.OriginalPhoto) PhotoStore.TryDelete(dlg.Result.PhotoPath);
                        Theme.Warn(this, err);
                        return;
                    }

                    if (dlg.Result.PhotoPath != dlg.OriginalPhoto) PhotoStore.TryDelete(dlg.OriginalPhoto);
                    Toast("Item updated.");
                    LoadItems();
                }
                catch (Exception ex)
                {
                    if (dlg.Result.PhotoPath != dlg.OriginalPhoto) PhotoStore.TryDelete(dlg.Result.PhotoPath);
                    Fail("updating the item", ex);
                }
            }
        }

        private void btnArchive_Click(object? sender, EventArgs e)
        {
            DataRowView? r = Selected(dgvItems);
            if (!IsAdmin || r == null) return;

            int id = Convert.ToInt32(r["ItemID"]);
            bool archived = Convert.ToInt32(r["ArchivedFlag"]) == 1;
            bool archive = !archived;

            try
            {
                if (archive)
                {
                    int pending = Repo.CountPendingClaims(id);
                    string msg = "Archive \"" + S(r, "ItemName") + "\"?\n\nIt will be hidden from students but kept in the records. You can restore it any time.";
                    if (pending > 0)
                        msg += "\n\n" + pending + " pending claim(s) on this item will be rejected.";
                    if (!Theme.Confirm(this, msg, "Archive item")) return;
                }

                string? err = Repo.SetArchived(userId, id, archive);
                if (err != null) { Theme.Warn(this, err); return; }

                Toast(archive ? "Item archived." : "Item restored.");
                LoadItems();
            }
            catch (Exception ex) { Fail("updating the item", ex); }
        }

        private void btnClaim_Click(object? sender, EventArgs e)
        {
            DataRowView? r = Selected(dgvItems);
            if (IsAdmin || r == null) return;

            int itemId = Convert.ToInt32(r["ItemID"]);
            string defaultContact = profile.ContactNumber.Length > 0 ? profile.ContactNumber : profile.Email;

            using (var dlg = new ClaimDialog(S(r, "ItemName"), defaultContact))
            {
                if (dlg.ShowDialog(this) != DialogResult.OK) return;

                try
                {
                    string? err = Repo.SubmitClaim(itemId, userId, dlg.Details, dlg.Contact, dlg.ProofPhotoName);
                    if (err != null)
                    {
                        PhotoStore.TryDelete(dlg.ProofPhotoName);
                        Theme.Warn(this, err);
                        LoadItems();
                        return;
                    }

                    Theme.Info(this, "Your claim was submitted. An administrator will review it and contact you.");
                    ShowView(viewMyClaims, navClaims);
                }
                catch (Exception ex)
                {
                    PhotoStore.TryDelete(dlg.ProofPhotoName);
                    Fail("submitting the claim", ex);
                }
            }
        }

        // ------------------------------------------------------------------
        // CLAIMS (admin review)
        // ------------------------------------------------------------------

        private DataTable? claimsTable;
        private DataView? claimsView;
        private Image? claimItemImage;
        private Image? claimProofImage;

        private void LoadClaims()
        {
            if (!IsAdmin) return;

            try
            {
                int keepId = Selected(dgvClaims) is DataRowView cur ? Convert.ToInt32(cur["ClaimID"]) : 0;

                claimsTable = Repo.GetAllClaims();
                claimsView = new DataView(claimsTable);
                dgvClaims.DataSource = claimsView;

                int pending = claimsTable.Select("RequestStatus = 'Pending'").Length;
                navClaims.Text = pending > 0 ? "Claim Requests  (" + pending + ")" : "Claim Requests";

                ApplyClaimFilter();

                if (dgvClaims.Rows.Count > 0)
                {
                    DataGridViewRow target = dgvClaims.Rows[0];
                    foreach (DataGridViewRow row in dgvClaims.Rows)
                        if (row.DataBoundItem is DataRowView v && Convert.ToInt32(v["ClaimID"]) == keepId) { target = row; break; }
                    dgvClaims.CurrentCell = target.Cells[0];
                    target.Selected = true;
                }
                ShowClaimDetails();
            }
            catch (Exception ex) { Fail("loading claims", ex); }
        }

        private void ApplyClaimFilter()
        {
            if (claimsView == null) return;

            var parts = new List<string>();
            string q = txtClaimSearch.Text.Trim();
            if (q.Length > 0)
            {
                string e = Theme.EscapeLike(q);
                parts.Add("(ItemName LIKE '%" + e + "%' OR FullName LIKE '%" + e + "%' OR Username LIKE '%" + e + "%')");
            }

            string status = Convert.ToString(cboClaimStatus.SelectedItem) ?? "All";
            if (status != "All") parts.Add("RequestStatus = '" + status + "'");

            try { claimsView.RowFilter = string.Join(" AND ", parts); }
            catch (EvaluateException) { claimsView.RowFilter = ""; }
        }

        private void ShowClaimDetails()
        {
            DataRowView? r = Selected(dgvClaims);

            Image? o1 = claimItemImage, o2 = claimProofImage;
            claimItemImage = claimProofImage = null;
            picClaimItem.Image = null;
            picClaimProof.Image = null;
            o1?.Dispose();
            o2?.Dispose();

            bool has = r != null;
            pnlClaimFields.Visible = has;
            lblNoClaim.Visible = !has;
            pnlClaimButtons.Visible = has;
            if (r == null) return;

            claimItemImage = PhotoStore.Load(S(r, "ItemPhoto"));
            claimProofImage = PhotoStore.Load(S(r, "ProofPhotoPath"));
            picClaimItem.Image = claimItemImage;
            picClaimProof.Image = claimProofImage;
            picClaimItem.Invalidate();
            picClaimProof.Invalidate();

            string status = S(r, "RequestStatus");
            lblCItem.Text = S(r, "ItemName");
            lblCStatus.Text = "  " + status.ToUpperInvariant() + "  ";
            lblCStatus.BackColor = StatusColor(status);
            lblCClaimant.Text = S(r, "FullName") + "  (" + S(r, "Username") + ")";

            var contacts = new List<string>();
            if (S(r, "ClaimContact").Length > 0) contacts.Add(S(r, "ClaimContact"));
            if (S(r, "ContactNumber").Length > 0 && !contacts.Contains(S(r, "ContactNumber"))) contacts.Add(S(r, "ContactNumber"));
            if (S(r, "Email").Length > 0 && !contacts.Contains(S(r, "Email"))) contacts.Add(S(r, "Email"));
            lblCContact.Text = contacts.Count > 0 ? string.Join("\n", contacts) : "Not provided";

            lblCDate.Text = r["RequestDate"] is DateTime d ? d.ToString("MMM d, yyyy  h:mm tt") : "";
            lblCDetails.Text = S(r, "ClaimDetails");

            bool pending = status == "Pending";
            btnApprove.Enabled = pending;
            btnReject.Enabled = pending;
        }

        private void ProcessSelectedClaim(string status)
        {
            DataRowView? r = Selected(dgvClaims);
            if (!IsAdmin || r == null) return;

            string verb = status == "Approved" ? "Approve" : "Reject";
            string msg = verb + " the claim by " + S(r, "FullName") + " for \"" + S(r, "ItemName") + "\"?";
            if (status == "Approved") msg += "\n\nThe item will be marked as claimed and other pending claims on it will be rejected.";
            if (!Theme.Confirm(this, msg, verb + " claim")) return;

            try
            {
                string? err = Repo.ProcessClaim(userId, Convert.ToInt32(r["ClaimID"]), status);
                if (err != null) Theme.Warn(this, err);
                else Toast("Claim " + status.ToLowerInvariant() + ".");

                LoadClaims();
                LoadItems();
            }
            catch (Exception ex) { Fail("processing the claim", ex); }
        }

        // ------------------------------------------------------------------
        // MY CLAIMS (user)
        // ------------------------------------------------------------------

        private void LoadMyClaims()
        {
            if (IsAdmin) return;

            try
            {
                DataTable t = Repo.GetClaimsForUser(userId);
                var old = dgvMyClaims.DataSource as DataTable;
                dgvMyClaims.DataSource = t;
                old?.Dispose();
                lblMyClaimsEmpty.Visible = t.Rows.Count == 0;
            }
            catch (Exception ex) { Fail("loading your claims", ex); }
        }

        // ------------------------------------------------------------------
        // USERS (admin)
        // ------------------------------------------------------------------

        private DataTable? usersTable;
        private DataView? usersView;

        private void LoadUsers()
        {
            if (!IsAdmin) return;

            try
            {
                int keepId = Selected(dgvUsers) is DataRowView cur ? Convert.ToInt32(cur["UserID"]) : 0;

                usersTable = Repo.GetUsers();
                usersView = new DataView(usersTable);
                dgvUsers.DataSource = usersView;
                ApplyUserFilter();

                if (dgvUsers.Rows.Count > 0)
                {
                    DataGridViewRow target = dgvUsers.Rows[0];
                    foreach (DataGridViewRow row in dgvUsers.Rows)
                        if (row.DataBoundItem is DataRowView v && Convert.ToInt32(v["UserID"]) == keepId) { target = row; break; }
                    dgvUsers.CurrentCell = target.Cells[0];
                    target.Selected = true;
                }
                UpdateUserButtons();
            }
            catch (Exception ex) { Fail("loading users", ex); }
        }

        private void ApplyUserFilter()
        {
            if (usersView == null) return;

            string q = txtUserSearch.Text.Trim();
            try
            {
                usersView.RowFilter = q.Length == 0 ? "" :
                    "(FullName LIKE '%" + Theme.EscapeLike(q) + "%' OR Username LIKE '%" + Theme.EscapeLike(q) + "%')";
            }
            catch (EvaluateException) { usersView.RowFilter = ""; }
        }

        private void UpdateUserButtons()
        {
            DataRowView? r = Selected(dgvUsers);
            if (r == null)
            {
                btnRole.Enabled = false;
                btnActive.Enabled = false;
                return;
            }

            bool self = Convert.ToInt32(r["UserID"]) == userId;
            bool isAdminRow = string.Equals(S(r, "UserRole"), "Admin", StringComparison.OrdinalIgnoreCase);
            bool inactive = Convert.ToInt32(r["InactiveFlag"]) == 1;

            btnRole.Text = isAdminRow ? "Demote to User" : "Promote to Admin";
            btnActive.Text = inactive ? "Reactivate" : "Deactivate";
            btnActive.BackColor = inactive ? Theme.Primary : Theme.Danger;
            btnRole.Enabled = !self;
            btnActive.Enabled = !self;
        }

        private void btnRole_Click(object? sender, EventArgs e)
        {
            DataRowView? r = Selected(dgvUsers);
            if (!IsAdmin || r == null) return;

            bool isAdminRow = string.Equals(S(r, "UserRole"), "Admin", StringComparison.OrdinalIgnoreCase);
            string newRole = isAdminRow ? "User" : "Admin";
            string name = S(r, "FullName");

            string msg = isAdminRow
                ? "Demote " + name + " to a regular user? They will lose admin access."
                : "Promote " + name + " to administrator? They will be able to manage items, claims and users.";
            if (!Theme.Confirm(this, msg, "Change role")) return;

            try
            {
                string? err = Repo.SetUserRole(userId, Convert.ToInt32(r["UserID"]), newRole);
                if (err != null) Theme.Warn(this, err);
                else Toast(name + " is now " + (newRole == "Admin" ? "an administrator." : "a regular user."));
                LoadUsers();
            }
            catch (Exception ex) { Fail("changing the role", ex); }
        }

        private void btnActive_Click(object? sender, EventArgs e)
        {
            DataRowView? r = Selected(dgvUsers);
            if (!IsAdmin || r == null) return;

            bool inactive = Convert.ToInt32(r["InactiveFlag"]) == 1;
            string name = S(r, "FullName");

            string msg = inactive
                ? "Reactivate " + name + "'s account?"
                : "Deactivate " + name + "'s account? They will no longer be able to sign in.";
            if (!Theme.Confirm(this, msg, inactive ? "Reactivate account" : "Deactivate account")) return;

            try
            {
                string? err = Repo.SetUserInactive(userId, Convert.ToInt32(r["UserID"]), !inactive);
                if (err != null) Theme.Warn(this, err);
                else Toast(name + (inactive ? " reactivated." : " deactivated."));
                LoadUsers();
            }
            catch (Exception ex) { Fail("updating the account", ex); }
        }

        // ------------------------------------------------------------------
        // PROFILE
        // ------------------------------------------------------------------

        private string? pendingAvatarSource;

        private void RefreshProfileView()
        {
            txtPFullName.Text = profile.FullName;
            txtPUsername.Text = profile.Username;
            txtPRole.Text = IsAdmin ? "Administrator" : "User";
            txtPEmail.Text = profile.Email;
            txtPContact.Text = profile.ContactNumber;
            pendingAvatarSource = null;
            SetAvatar(picProfile, profile.PhotoPath, profile.FullName.Length > 0 ? profile.FullName : fullName);
        }

        private void btnChangeAvatar_Click(object? sender, EventArgs e)
        {
            string? path = PhotoStore.PickPhoto(this);
            if (path == null) return;

            Image? img = PhotoStore.LoadForPreview(path, out string? error);
            if (img == null) { Theme.Warn(this, error ?? "Could not load that image."); return; }

            pendingAvatarSource = path;
            Image? old = picProfile.Image;
            picProfile.Image = img;
            old?.Dispose();
        }

        private void btnSaveProfile_Click(object? sender, EventArgs e)
        {
            string name = txtPFullName.Text.Trim();
            string email = txtPEmail.Text.Trim();
            string contact = txtPContact.Text.Trim();

            if (name.Length == 0) { Theme.Warn(this, "Your name can't be empty."); return; }
            if (email.Length > 0 && !EmailRule.IsMatch(email)) { Theme.Warn(this, "That email address doesn't look right."); return; }
            if (contact.Length > 0 && !PhoneRule.IsMatch(contact)) { Theme.Warn(this, "Contact number can only contain digits, +, -, spaces and brackets (7-20 characters)."); return; }

            string? newPhoto = profile.PhotoPath;
            string? oldPhoto = profile.PhotoPath;

            try
            {
                if (pendingAvatarSource != null)
                    newPhoto = PhotoStore.Save(pendingAvatarSource);

                Repo.UpdateProfile(userId, name, email, contact, newPhoto);

                if (newPhoto != oldPhoto) PhotoStore.TryDelete(oldPhoto);

                profile.FullName = name;
                profile.Email = email;
                profile.ContactNumber = contact;
                profile.PhotoPath = newPhoto;
                fullName = name;

                RefreshHeaderUser();
                RefreshProfileView();
                Toast("Profile saved.");
            }
            catch (InvalidOperationException ex) { Theme.Warn(this, ex.Message); }
            catch (Exception ex) { Fail("saving your profile", ex); }
        }

        private void btnChangePassword_Click(object? sender, EventArgs e)
        {
            string current = txtCurPass.Text;
            string next = txtNewPass.Text;
            string confirm = txtConfPass.Text;

            if (current.Length == 0 || next.Length == 0 || confirm.Length == 0)
            { Theme.Warn(this, "Please fill in all three password fields."); return; }
            if (next != confirm) { Theme.Warn(this, "The new passwords do not match."); return; }
            if (next == current) { Theme.Warn(this, "The new password must be different from the current one."); return; }

            string? weak = PasswordHelper.Validate(next);
            if (weak != null) { Theme.Warn(this, weak); return; }

            try
            {
                string? err = Repo.ChangePassword(userId, current, next);
                if (err != null) { Theme.Warn(this, err); return; }

                txtCurPass.Clear();
                txtNewPass.Clear();
                txtConfPass.Clear();
                Theme.Info(this, "Your password was changed.");
            }
            catch (Exception ex) { Fail("changing your password", ex); }
        }

        // ------------------------------------------------------------------

        private void btnLogout_Click(object? sender, EventArgs e)
        {
            Close();
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                toastTimer?.Dispose();
                detailImage?.Dispose();
                claimItemImage?.Dispose();
                claimProofImage?.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
